// theme.ts — একমাত্র সত্যের উৎস: রং, ইজিং, spring, ফন্ট। কম্পোনেন্টে সরাসরি হেক্স নয়।
import {Easing} from 'remotion';

export const theme = {
  // ইউজারের দেওয়া স্কিম (w1last)
  colors: {
    bg: '#080E1B',
    bgAlt: '#0C1628',
    surface: '#172338',
    surfaceHi: '#1F3050',
    primary: '#1267F5', // HERO — এক ফ্রেমে বড়জোর একটি এলিমেন্টে গ্লো
    accent: '#16C7F3',
    text: '#F4F7FC',
    textDim: '#9DB0CE',
    success: '#22C58B',
  },
  rgb: {
    bg: '8,14,27',
    surface: '23,35,56',
    primary: '18,103,245',
    accent: '22,199,243',
    text: '244,247,252',
    success: '34,197,139',
  },
  fonts: {
    display: '"Hind Siliguri", system-ui, sans-serif',
    mono: '"JetBrains Mono", ui-monospace, monospace',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
  fps: 30,
  width: 1920,
  height: 1080,
} as const;

export type RGBKey = keyof typeof theme.rgb;
export const rgba = (k: RGBKey, a: number) => `rgba(${theme.rgb[k]},${a})`;
