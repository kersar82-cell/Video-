import React from 'react';
import {AbsoluteFill, Audio, getRemotionEnvironment, interpolate, staticFile, useCurrentFrame, delayRender, continueRender} from 'remotion';
import {theme, rgba} from '../theme';
import {config} from '../config';

/** লেয়ার ১: ব্যাকগ্রাউন্ড মেশ + টেক গ্রিড (কখনো ফ্ল্যাট একরঙা নয়) */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 90) * 70;
  const d2 = Math.cos(frame / 110) * 55;
  const gx = (frame * 0.25) % 90;
  return (
    <AbsoluteFill style={{background: `radial-gradient(120% 90% at 50% 0%, ${theme.colors.bgAlt}, ${theme.colors.bg} 70%)`}}>
      <div style={{position: 'absolute', width: 1300, height: 1300, borderRadius: '50%', top: -560 + d2, left: -380 + d1, filter: 'blur(60px)', background: `radial-gradient(circle, ${rgba('primary', 0.20)}, transparent 62%)`}} />
      <div style={{position: 'absolute', width: 1000, height: 1000, borderRadius: '50%', bottom: -480 - d1, right: -300 - d2, filter: 'blur(70px)', background: `radial-gradient(circle, ${rgba('accent', 0.13)}, transparent 65%)`}} />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(${rgba('text', 0.035)} 1px, transparent 1px), linear-gradient(90deg, ${rgba('text', 0.035)} 1px, transparent 1px)`,
          backgroundSize: '90px 90px',
          backgroundPosition: `${gx}px ${gx * 0.6}px`,
          WebkitMaskImage: 'radial-gradient(ellipse at center, black 25%, transparent 80%)',
          maskImage: 'radial-gradient(ellipse at center, black 25%, transparent 80%)',
        }}
      />
    </AbsoluteFill>
  );
};

/** লেয়ার ৪: কালার গ্রেড */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.primary, mixBlendMode: 'soft-light', opacity: 0.16}} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.22))'}} />
  </AbsoluteFill>
);

/** লেয়ার ৫: গ্রেইন + ভিনিয়েট */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', backgroundImage: noise, backgroundSize: '220px', backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.05, mixBlendMode: 'overlay'}} />
  );
};
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.30) 100%)'}} />
);

/** সিন ট্রানজিশন: আলোর swipe — কাট এর মাঝখানে লুকানো */
export const Wipe: React.FC = () => {
  const frame = useCurrentFrame();
  const x = interpolate(frame, [0, 15], [-1500, 2500], {easing: theme.ease.inOut, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const o = interpolate(frame, [0, 4, 11, 15], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: o}}>
      <div style={{position: 'absolute', top: -100, bottom: -100, left: 0, width: 760, transform: `translateX(${x}px) skewX(-16deg)`, background: `linear-gradient(90deg, transparent, ${rgba('primary', 0.22)} 35%, ${rgba('accent', 0.42)} 62%, transparent)`, filter: 'blur(26px)'}} />
      <div style={{position: 'absolute', top: -100, bottom: -100, left: 0, width: 4, transform: `translateX(${x + 470}px) skewX(-16deg)`, background: rgba('accent', 0.85), filter: 'blur(1px)'}} />
    </AbsoluteFill>
  );
};

/** প্রিভিউ অডিও: public/voiceover.mp3 থাকলে বাজবে। রেন্ডারে ডিফল্টে বন্ধ (includeVoiceover প্রপ দিলে চালু) */
export const PreviewAudio: React.FC<{includeVoiceover?: boolean}> = ({includeVoiceover}) => {
  const env = getRemotionEnvironment();
  const [exists, setExists] = React.useState(false);
  const [handle] = React.useState(() => delayRender('voiceover-check'));
  React.useEffect(() => {
    fetch(staticFile(config.voiceoverFile))
      .then((r) => setExists(r.ok && (r.headers.get('content-type') || '').includes('audio')))
      .catch(() => setExists(false))
      .finally(() => continueRender(handle));
  }, [handle]);
  const enabled = env.isRendering ? !!includeVoiceover : true;
  if (!exists || !enabled) return null;
  return <Audio src={staticFile(config.voiceoverFile)} />;
};
