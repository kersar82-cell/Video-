import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, rgba} from '../theme';
import {Icon} from './Icon';

const clamp01 = (n: number) => Math.min(Math.max(n, 0), 1);
const useSp = (delay: number, cfg: {damping: number; stiffness: number; mass: number} = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: cfg});
};

/** ডোনাট রিং */
export const Donut: React.FC<{pct: number; size: number; delay: number; color: string; hero?: boolean; children?: React.ReactNode; thick?: number}> = ({
  pct, size, delay, color, hero, children, thick = 26,
}) => {
  const p = clamp01(useSp(delay, {damping: 26, stiffness: 50, mass: 1}));
  const r = (size - thick) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div style={{position: 'relative', width: size, height: size, filter: hero ? `drop-shadow(0 0 28px ${rgba('primary', 0.55)})` : undefined}}>
      <svg width={size} height={size} style={{transform: 'rotate(-90deg)'}}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={rgba('text', 0.09)} strokeWidth={thick} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={thick} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - (pct / 100) * p)} />
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column'}}>{children}</div>
    </div>
  );
};

/** স্পিডোমিটার গজ */
export const Gauge: React.FC<{delay: number; size?: number; level?: number}> = ({delay, size = 640, level = 0.92}) => {
  const frame = useCurrentFrame();
  const p = clamp01(useSp(delay, {damping: 22, stiffness: 45, mass: 1}));
  const R = size / 2 - 40;
  const cx = size / 2;
  const cy = size / 2;
  const arc = `M ${cx - R} ${cy} A ${R} ${R} 0 0 1 ${cx + R} ${cy}`;
  const ang = -90 + 180 * level * p + Math.sin(frame / 5) * 1.4 * p;
  return (
    <svg width={size} height={size / 2 + 60} style={{overflow: 'visible'}}>
      <defs>
        <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={theme.colors.accent} />
          <stop offset="100%" stopColor={theme.colors.primary} />
        </linearGradient>
      </defs>
      <path d={arc} fill="none" stroke={rgba('text', 0.09)} strokeWidth={34} strokeLinecap="round" />
      <path d={arc} fill="none" stroke="url(#gaugeGrad)" strokeWidth={34} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - level * p} style={{filter: `drop-shadow(0 0 18px ${rgba('primary', 0.6)})`}} />
      {Array.from({length: 13}).map((_, i) => {
        const a = (Math.PI * i) / 12;
        const x1 = cx - Math.cos(a) * (R - 40);
        const y1 = cy - Math.sin(a) * (R - 40);
        const x2 = cx - Math.cos(a) * (R - (i % 3 === 0 ? 70 : 58));
        const y2 = cy - Math.sin(a) * (R - (i % 3 === 0 ? 70 : 58));
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={rgba('text', 0.35)} strokeWidth={3} strokeLinecap="round" />;
      })}
      <g transform={`rotate(${ang} ${cx} ${cy})`}>
        <line x1={cx} y1={cy} x2={cx} y2={cy - R + 78} stroke={theme.colors.text} strokeWidth={7} strokeLinecap="round" />
      </g>
      <circle cx={cx} cy={cy} r={20} fill={theme.colors.surface} stroke={theme.colors.text} strokeWidth={5} />
    </svg>
  );
};

/** ট্রাফিক লাইন চার্ট: স্বাভাবিক বেসলাইন বনাম স্পাইক (২×) */
export const SpikeChart: React.FC<{w: number; h: number; delay: number; spikeDelay: number}> = ({w, h, delay, spikeDelay}) => {
  const frame = useCurrentFrame();
  const draw = clamp01(useSp(delay, {damping: 30, stiffness: 40, mass: 1}));
  const spike = clamp01(useSp(spikeDelay, {damping: 18, stiffness: 70, mass: 1}));
  const base = h * 0.66;
  const peak = h * 0.2; // ২× = বেসলাইনের দ্বিগুণ উচ্চতা
  const N = 60;
  const pts: string[] = [];
  for (let i = 0; i <= N; i++) {
    const x = (i / N) * w;
    const t = i / N;
    const bump = t > 0.38 ? clamp01((t - 0.38) / 0.1) : 0;
    const hold = t > 0.5 ? 1 : bump;
    const noise = Math.sin(i * 1.7) * 4 + Math.sin(i * 0.6 + frame / 12) * 3;
    const y = base + noise - (base - peak) * hold * spike;
    pts.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  const d = pts.join(' ');
  return (
    <svg width={w} height={h} style={{overflow: 'visible'}}>
      {[0.2, 0.43, 0.66, 0.89].map((g, i) => (
        <line key={i} x1={0} x2={w} y1={h * g} y2={h * g} stroke={rgba('text', 0.07)} strokeWidth={2} />
      ))}
      <line x1={0} x2={w} y1={base} y2={base} stroke={rgba('text', 0.35)} strokeWidth={3} strokeDasharray="12 12" />
      <path d={`${d} L ${w} ${h} L 0 ${h} Z`} fill={rgba('primary', 0.14 * draw)} />
      <path d={d} fill="none" stroke={theme.colors.accent} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} style={{filter: `drop-shadow(0 0 14px ${rgba('accent', 0.55)})`}} />
    </svg>
  );
};

/** ঘুরন্ত গ্লোব (ওয়্যারফ্রেম) + পালস নোড */
export const Globe: React.FC<{size: number; delay: number}> = ({size, delay}) => {
  const frame = useCurrentFrame();
  const p = clamp01(useSp(delay));
  const R = size / 2 - 10;
  const c = size / 2;
  const nodes = [[-0.55, -0.4], [0.5, -0.5], [-0.8, 0.1], [0.78, 0.15], [-0.3, 0.55], [0.35, 0.62], [0.0, -0.78]];
  return (
    <svg width={size} height={size} style={{opacity: p, transform: `scale(${0.9 + 0.1 * p})`}}>
      <circle cx={c} cy={c} r={R} fill={rgba('primary', 0.10)} stroke={rgba('accent', 0.55)} strokeWidth={3} />
      {[0, 1, 2, 3].map((k) => {
        const a = frame * 0.022 + (k * Math.PI) / 4;
        return <ellipse key={k} cx={c} cy={c} rx={Math.abs(Math.cos(a)) * R} ry={R} fill="none" stroke={rgba('accent', 0.28)} strokeWidth={2} />;
      })}
      {[-0.55, -0.2, 0.2, 0.55].map((l, i) => (
        <ellipse key={i} cx={c} cy={c + l * R} rx={Math.sqrt(1 - l * l) * R} ry={Math.sqrt(1 - l * l) * R * 0.14} fill="none" stroke={rgba('accent', 0.22)} strokeWidth={2} />
      ))}
      {nodes.map(([nx, ny], i) => {
        const pulse = (frame / 36 + i * 0.21) % 1;
        const x = c + nx * R;
        const y = c + ny * R;
        return (
          <g key={i}>
            <circle cx={x} cy={y} r={7} fill={theme.colors.accent} />
            <circle cx={x} cy={y} r={7 + pulse * 30} fill="none" stroke={theme.colors.accent} strokeOpacity={1 - pulse} strokeWidth={3} />
          </g>
        );
      })}
    </svg>
  );
};

/** মেসেজ কিউ: পাইপ দিয়ে চিঠির প্রবাহ */
export const QueuePipe: React.FC<{w: number; delay: number}> = ({w, delay}) => {
  const frame = useCurrentFrame();
  const p = clamp01(useSp(delay));
  const n = 9;
  const speed = 7;
  return (
    <div style={{position: 'relative', width: w, height: 190, opacity: p, overflow: 'hidden', borderRadius: 60}}>
      <div style={{position: 'absolute', left: 0, right: 0, top: 40, height: 110, borderRadius: 55, background: rgba('surface', 0.9), border: `2px solid ${rgba('accent', 0.35)}`, boxShadow: `inset 0 0 40px ${rgba('primary', 0.25)}`}} />
      {Array.from({length: n}).map((_, i) => {
        const gap = (w + 160) / n;
        const x = ((frame * speed + i * gap) % (w + 160)) - 120;
        return (
          <div key={i} style={{position: 'absolute', left: x, top: 62, width: 92, height: 66, borderRadius: 14, background: i % 3 === 0 ? theme.colors.primary : theme.colors.surfaceHi, border: `2px solid ${rgba('accent', 0.55)}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Icon n="mail" size={38} color={theme.colors.text} />
          </div>
        );
      })}
      <div style={{position: 'absolute', left: -6, top: 28, width: 30, height: 134, borderRadius: 16, background: `linear-gradient(90deg, ${theme.colors.bg}, transparent)`}} />
    </div>
  );
};

/** একটি চেকলিস্ট সারি */
export const CheckRow: React.FC<{delay: number; text: string; icon?: string; tone?: 'success' | 'accent' | 'dim'; size?: number; w?: number}> = ({
  delay, text, icon = 'check', tone = 'success', size = 40, w,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = clamp01(spring({frame: frame - delay, fps, config: theme.spring.snappy}));
  const c = tone === 'success' ? theme.colors.success : tone === 'accent' ? theme.colors.accent : theme.colors.textDim;
  const k = tone === 'success' ? 'success' : tone === 'accent' ? 'accent' : 'text';
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 22, width: w, opacity: p, transform: `translateX(${(1 - p) * -40}px)`}}>
      <div style={{width: size * 1.5, height: size * 1.5, borderRadius: size * 0.45, background: rgba(k, 0.14), border: `1.5px solid ${rgba(k, 0.4)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>
        <Icon n={icon} size={size} color={c} stroke={2.2} />
      </div>
      <div style={{fontSize: size, fontWeight: 600, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text}}>{text}</div>
    </div>
  );
};

/** ছোট পেজ টাইল (মানুষ বনাম ক্রলার চিত্রে) */
export const PageTile: React.FC<{lit: number; size?: number; hero?: boolean}> = ({lit, size = 86, hero}) => (
  <div style={{width: size, height: size * 1.2, borderRadius: 14, backgroundColor: lit > 0.5 ? (hero ? rgba('primary', 0.9) : rgba('accent', 0.22)) : theme.colors.surface, border: `2px solid ${lit > 0.5 ? rgba('accent', 0.7) : rgba('text', 0.08)}`, boxShadow: lit > 0.5 && hero ? `0 0 30px ${rgba('primary', 0.6)}` : undefined, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.92 + 0.08 * lit})`}}>
    <Icon n="doc" size={size * 0.5} color={lit > 0.5 ? theme.colors.text : theme.colors.textDim} />
  </div>
);
