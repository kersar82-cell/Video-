import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, rgba} from '../theme';
import {Icon} from './Icon';

/* ---------- সময়: সব হিসাব SRT-এর সেকেন্ড থেকে ---------- */
export const SceneCtx = createContext({startSec: 0, endSec: 1});

/** abs সেকেন্ড -> সিনের ভেতরের ফ্রেম; ভিজ্যুয়াল কথার ৫ ফ্রেম আগে ঢোকে */
export const useT = () => {
  const {fps} = useVideoConfig();
  const {startSec} = useContext(SceneCtx);
  return (abs: number, lead = 5) => Math.max(0, Math.round((abs - startSec) * fps) - lead);
};

/* ---------- বাংলা সংখ্যা ---------- */
const D = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export const bn = (s: string | number) => String(s).replace(/[0-9]/g, (d) => D[+d]);
export const bnInt = (n: number) => {
  const s = Math.round(n).toString();
  if (s.length <= 3) return bn(s);
  const last3 = s.slice(-3);
  const rest = s.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return bn(rest + ',' + last3);
};

/* ---------- SFX (ইউজারের দেওয়া সাউন্ড, ছাঁটা) ---------- */
export type SfxName = 'whoosh' | 'swipe' | 'pop' | 'click' | 'tick' | 'chime' | 'success';
const sfxVol: Record<SfxName, number> = {whoosh: 0.3, swipe: 0.22, pop: 0.3, click: 0.28, tick: 0.3, chime: 0.28, success: 0.26};
export const Sfx: React.FC<{t: number; n: SfxName; v?: number; rate?: number}> = ({t, n, v, rate = 1}) => {
  const {fps} = useVideoConfig();
  const {startSec} = useContext(SceneCtx);
  const from = Math.max(0, Math.round((t - startSec) * fps) - 3); // ভিজ্যুয়াল ল্যান্ড করার ২-৩ ফ্রেম আগে
  return (
    <Sequence from={from} layout="none">
      <Audio src={staticFile(`sfx/${n}.wav`)} volume={v ?? sfxVol[n]} playbackRate={rate} />
    </Sequence>
  );
};

/* ---------- মোশন ব্লক ---------- */
export const Entrance: React.FC<{
  delay?: number; dy?: number; dx?: number; from?: number; outAt?: number;
  cfg?: keyof typeof theme.spring; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({delay = 0, dy = 36, dx = 0, from = 0.94, outAt, cfg = 'smooth', style, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring[cfg]});
  let o = Math.min(Math.max(p, 0), 1);
  let ey = 0;
  if (outAt !== undefined) {
    const q = interpolate(frame, [outAt, outAt + 9], [0, 1], {easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
    o *= 1 - q;
    ey = -30 * q;
  }
  return (
    <div style={{opacity: o, transform: `translate(${dx * (1 - p)}px, ${dy * (1 - p) + ey}px) scale(${interpolate(p, [0, 1], [from, 1])})`, ...style}}>
      {children}
    </div>
  );
};

export const Float: React.FC<{amp?: number; speed?: number; phase?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({
  amp = 6, speed = 32, phase = 0, style, children,
}) => {
  const frame = useCurrentFrame();
  return <div style={{transform: `translateY(${Math.sin(frame / speed + phase) * amp}px)`, ...style}}>{children}</div>;
};

/** শব্দ ধরে স্ট্যাগার্ড (বাংলা: শুধু স্পেসে ভাঙে, অক্ষরে নয়)। '*' দিয়ে শুরু হলে হাইলাইট */
export const WordReveal: React.FC<{
  text: string; delay?: number; per?: number; size?: number; weight?: number; color?: string;
  align?: 'left' | 'center'; maxWidth?: number; outAt?: number; lineHeight?: number; style?: React.CSSProperties;
}> = ({text, delay = 0, per = 3, size = 84, weight = 700, color = theme.colors.text, align = 'left', maxWidth, outAt, lineHeight = 1.28, style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const q = outAt === undefined ? 0 : interpolate(frame, [outAt, outAt + 9], [0, 1], {easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', columnGap: Math.round(size * 0.26), rowGap: 0, justifyContent: align === 'center' ? 'center' : 'flex-start', maxWidth, fontSize: size, fontWeight: weight, lineHeight, color, letterSpacing: 0, opacity: 1 - q, transform: `translateY(${-24 * q}px)`, ...style}}>
      {text.split(' ').map((raw, i) => {
        const hl = raw.startsWith('*');
        const word = hl ? raw.slice(1) : raw;
        const d = delay + i * per;
        const p = spring({frame: frame - d, fps, config: theme.spring.snappy});
        const pill = spring({frame: frame - d - 5, fps, config: theme.spring.smooth});
        return (
          <span key={i} style={{position: 'relative', display: 'inline-block', opacity: Math.min(Math.max(p, 0), 1), transform: `translateY(${interpolate(p, [0, 1], [32, 0])}px)`, color: hl ? theme.colors.accent : color}}>
            {hl && (
              <span style={{position: 'absolute', left: -12, right: -12, top: size * 0.14, bottom: size * 0.02, borderRadius: size * 0.2, background: rgba('accent', 0.14), border: `1.5px solid ${rgba('accent', 0.32)}`, opacity: Math.min(Math.max(pill, 0), 1), transform: `scaleX(${interpolate(pill, [0, 1], [0.6, 1])})`, zIndex: -1}} />
            )}
            {word}
          </span>
        );
      })}
    </div>
  );
};

export const GlassCard: React.FC<{style?: React.CSSProperties; hero?: boolean; children?: React.ReactNode}> = ({style, hero, children}) => (
  <div
    style={{
      position: 'relative',
      borderRadius: 30,
      background: `linear-gradient(155deg, ${rgba('surface', 0.94)}, ${rgba('surface', 0.62)})`,
      border: `1.5px solid ${hero ? rgba('accent', 0.45) : rgba('text', 0.10)}`,
      boxShadow: `0 40px 80px -30px rgba(0,0,0,0.7), inset 0 1px 0 ${rgba('text', 0.10)}${hero ? `, 0 0 90px ${rgba('primary', 0.38)}` : ''}`,
      overflow: 'hidden',
      ...style,
    }}
  >
    {children}
  </div>
);

export const Tag: React.FC<{text: string; icon?: string; tone?: 'accent' | 'dim' | 'success'; size?: number}> = ({text, icon, tone = 'accent', size = 30}) => {
  const c = tone === 'accent' ? theme.colors.accent : tone === 'success' ? theme.colors.success : theme.colors.textDim;
  const k = tone === 'accent' ? 'accent' : tone === 'success' ? 'success' : 'text';
  return (
    <div style={{display: 'inline-flex', alignItems: 'center', gap: 12, padding: `${size * 0.3}px ${size * 0.7}px`, borderRadius: 999, background: rgba(k, 0.12), border: `1.5px solid ${rgba(k, 0.32)}`, color: c, fontSize: size, fontWeight: 600, letterSpacing: 0, lineHeight: 1.2}}>
      {icon && <Icon n={icon} size={size * 1.05} color={c} />}
      <span>{text}</span>
    </div>
  );
};

export const gradText: React.CSSProperties = {
  background: `linear-gradient(180deg, ${theme.colors.text} 35%, ${theme.colors.accent} 130%)`,
  WebkitBackgroundClip: 'text',
  backgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  color: 'transparent',
};

export const Counter: React.FC<{to: number; delay?: number; decimals?: number; format?: (n: number) => string; style?: React.CSSProperties}> = ({
  to, delay = 0, decimals = 0, format, style,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: {damping: 30, stiffness: 55, mass: 1}});
  const v = to * Math.min(Math.max(p, 0), 1);
  return <span style={{fontVariantNumeric: 'tabular-nums', letterSpacing: 0, ...style}}>{format ? format(v) : bn(v.toFixed(decimals))}</span>;
};

/** স্থির ছবিতে ধীর Ken Burns */
export const KenBurns: React.FC<{src: string; zoomTo?: number; panX?: number; fit?: 'cover' | 'contain'; style?: React.CSSProperties}> = ({
  src, zoomTo = 1.08, panX = -14, fit = 'cover', style,
}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const s = interpolate(frame, [0, durationInFrames], [1, zoomTo], {easing: theme.ease.inOut, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const x = interpolate(frame, [0, durationInFrames], [0, panX], {easing: theme.ease.inOut, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: fit, transform: `scale(${s}) translateX(${x}px)`, ...style}} />;
};

/** লোগো টাইল: লোগো যেমন আছে তেমন (বিকৃত নয়), গোলাকার কার্ডে */
export const LogoTile: React.FC<{src: string; w: number; h?: number; bg?: string; fit?: 'cover' | 'contain'; pad?: number; radius?: number; zoom?: number; style?: React.CSSProperties}> = ({
  src, w, h, bg = '#FFFFFF', fit = 'contain', pad = 0, radius = 34, zoom = 1.05, style,
}) => (
  <div style={{width: w, height: h ?? w, borderRadius: radius, overflow: 'hidden', background: bg, padding: pad, boxSizing: 'border-box', boxShadow: `0 30px 60px -20px rgba(0,0,0,0.65), 0 0 0 1.5px ${rgba('text', 0.14)}`, ...style}}>
    <KenBurns src={src} fit={fit} zoomTo={zoom} panX={0} />
  </div>
);

/** ক্যারেক্টার পোজ — ইমোশন অনুযায়ী, কম ব্যবহার */
export const Character: React.FC<{pose: string; h: number; delay?: number; outAt?: number; flip?: boolean; style?: React.CSSProperties}> = ({
  pose, h, delay = 0, outAt, flip, style,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring.bouncy});
  const q = outAt === undefined ? 0 : interpolate(frame, [outAt, outAt + 9], [0, 1], {easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const bob = Math.sin(frame / 26) * 5;
  return (
    <div style={{position: 'absolute', opacity: Math.min(Math.max(p, 0), 1) * (1 - q), transform: `translateY(${(1 - p) * 120 + bob + q * 60}px) scale(${interpolate(p, [0, 1], [0.85, 1])})`, transformOrigin: '50% 100%', filter: 'drop-shadow(0 30px 40px rgba(0,0,0,0.55))', ...style}}>
      <Img src={staticFile(`char/${pose}.png`)} style={{height: h, display: 'block', transform: flip ? 'scaleX(-1)' : undefined}} />
    </div>
  );
};

export const Spot: React.FC<{x: number; y: number; c?: 'primary' | 'accent'; r?: number; o?: number}> = ({x, y, c = 'primary', r = 900, o = 0.5}) => {
  const frame = useCurrentFrame();
  const a = interpolate(frame, [0, 24], [0, o], {easing: theme.ease.out, extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: x - r / 2 + Math.sin(frame / 60) * 24, top: y - r / 2 + Math.cos(frame / 75) * 18, width: r, height: r, borderRadius: '50%', opacity: a, background: `radial-gradient(circle, ${rgba(c, 0.30)}, transparent 64%)`, filter: 'blur(30px)'}} />
  );
};

/** সিনের মোড়ক: স্পটলাইট + দ্রুত এক্সিট (এন্ট্রির চেয়ে দ্রুত) */
export const SceneFrame: React.FC<{spot?: {x: number; y: number; c?: 'primary' | 'accent'; r?: number; o?: number}; noExit?: boolean; children?: React.ReactNode}> = ({
  spot, noExit, children,
}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const e = noExit ? 0 : interpolate(frame, [durationInFrames - 9, durationInFrames - 1], [0, 1], {easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{opacity: 1 - e, transform: `translateY(${-22 * e}px) scale(${1 + 0.012 * e})`, fontFamily: theme.fonts.display, color: theme.colors.text}}>
      {spot && <Spot {...spot} />}
      {children}
    </AbsoluteFill>
  );
};

export const Abs: React.FC<{x: number; y: number; w?: number; h?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({x, y, w, h, style, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, ...style}}>{children}</div>
);
