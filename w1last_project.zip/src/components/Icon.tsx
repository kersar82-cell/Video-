import React from 'react';
import {theme} from '../theme';

// ইমোজি নয় — থিমের রঙে আঁকা SVG আইকন
const paths: Record<string, React.ReactNode> = {
  bot: (<><rect x="5" y="8" width="14" height="11" rx="3.5"/><path d="M12 8V4.5"/><circle cx="12" cy="3.6" r="1.1"/><circle cx="9.3" cy="13.2" r="1.2"/><circle cx="14.7" cy="13.2" r="1.2"/><path d="M3 12.5v3M21 12.5v3M9.5 16.6h5"/></>),
  user: (<><circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c0-4.2 3.4-6.5 7.5-6.5s7.5 2.3 7.5 6.5"/></>),
  server: (<><rect x="3.5" y="4" width="17" height="6.5" rx="2"/><rect x="3.5" y="13.5" width="17" height="6.5" rx="2"/><path d="M7 7.3h.01M7 16.8h.01M11 7.3h6M11 16.8h6"/></>),
  database: (<><ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V6"/><path d="M4.5 12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3"/></>),
  bolt: <path d="M13 2.5 5 13.5h6l-1 8 8-11h-6z"/>,
  shield: (<><path d="M12 3 5 6v6c0 4.5 3 7.4 7 9 4-1.6 7-4.5 7-9V6z"/><path d="M9 12l2.2 2.2L15.2 10"/></>),
  check: <path d="M5 12.5l4.6 4.6L19 7.4"/>,
  cross: <path d="M6 6l12 12M18 6 6 18"/>,
  question: (<><circle cx="12" cy="12" r="9"/><path d="M9.6 9.3c.3-1.5 1.5-2.3 2.8-2.3 1.7 0 2.8 1.1 2.8 2.5 0 2-2.7 2.3-2.7 4.2"/><path d="M12.5 17.3h.01"/></>),
  clock: (<><circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/></>),
  globe: (<><circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/></>),
  doc: (<><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M9.5 12h5M9.5 15.5h5"/></>),
  chip: (<><rect x="7" y="7" width="10" height="10" rx="2"/><rect x="10" y="10" width="4" height="4" rx="1"/><path d="M9.5 3.5v3.5M14.5 3.5v3.5M9.5 17v3.5M14.5 17v3.5M3.5 9.5H7M3.5 14.5H7M17 9.5h3.5M17 14.5h3.5"/></>),
  search: (<><circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5.5 5.5"/></>),
  sms: (<><path d="M4 5h16v11H11l-4.5 3.5V16H4z"/><path d="M8 9.5h8M8 12.5h5"/></>),
  link: (<><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></>),
  cloud: <path d="M7 18.5h10.2a4 4 0 0 0 .7-7.9A6 6 0 0 0 6.4 9.4 4.6 4.6 0 0 0 7 18.5z"/>,
  calendar: (<><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></>),
  play: <path d="M8 5.5v13l11-6.5z"/>,
  phone: (<><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></>),
  key: (<><circle cx="8" cy="15" r="3.8"/><path d="M10.8 12.2 20 3M16 7l3 3M14 9l2 2"/></>),
  card: (<><rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6 15h4"/></>),
  arrowUp: <path d="M12 19.5v-15M5.5 11 12 4.5l6.5 6.5"/>,
  arrowRight: <path d="M4.5 12h15M13 5.5l6.5 6.5-6.5 6.5"/>,
  alert: (<><path d="M12 3.5 2.5 20h19z"/><path d="M12 10v4.5M12 17.2h.01"/></>),
  layers: (<><path d="M12 3.5 3 8.5l9 5 9-5z"/><path d="M3 12.5l9 5 9-5M3 16.5l9 5 9-5"/></>),
  box: (<><path d="M12 3 3.5 7.5v9L12 21l8.5-4.5v-9z"/><path d="M3.5 7.5 12 12l8.5-4.5M12 12v9"/></>),
  ring: (<><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.2"/></>),
  queue: (<><rect x="2.5" y="8" width="5" height="8" rx="1.4"/><rect x="9.5" y="8" width="5" height="8" rx="1.4"/><rect x="16.5" y="8" width="5" height="8" rx="1.4"/></>),
  flask: (<><path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/><path d="M7.5 15h9"/></>),
  mail: (<><rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3.5 7.5 12 13l8.5-5.5"/></>),
  users: (<><circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c0-3.4 2.7-5.2 6-5.2s6 1.8 6 5.2"/><circle cx="17" cy="9.5" r="2.5"/><path d="M17.5 14.4c2.3.2 3.9 1.8 3.9 4.6"/></>),
  gauge: (<><path d="M4 16a8 8 0 1 1 16 0"/><path d="M12 16l4-5"/></>),
  image: (<><rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M4 17l5-4.5 4 3.5 3-2.5 4 3.5"/></>),
  wifi: (<><path d="M3 9.5a13 13 0 0 1 18 0M6 13a8.5 8.5 0 0 1 12 0M9 16.5a4 4 0 0 1 6 0"/><path d="M12 19.5h.01"/></>),
  route: (<><circle cx="6" cy="6" r="2.2"/><circle cx="18" cy="18" r="2.2"/><path d="M8.2 6H15a3 3 0 0 1 0 6H9a3 3 0 0 0 0 6h6.8"/></>),
  lock: (<><rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/></>),
  eye: (<><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></>),
};

export type IconName = keyof typeof paths | string;

export const Icon: React.FC<{n: IconName; size?: number; color?: string; stroke?: number; fill?: string; style?: React.CSSProperties}> = ({
  n,
  size = 40,
  color = theme.colors.text,
  stroke = 1.8,
  fill = 'none',
  style,
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={{flexShrink: 0, ...style}}>
    {paths[n]}
  </svg>
);
