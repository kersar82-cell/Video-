import {continueRender, delayRender, staticFile} from 'remotion';

const BN = 'U+0951-0952,U+0964-0965,U+0980-09FE,U+1CF7,U+200C-200D,U+20B9,U+25CC';
const LA = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-200B,U+200E-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';

const specs = [
  ...[500, 600, 700].flatMap((w) => [
    {family: 'Hind Siliguri', file: `fonts/hind-siliguri-bengali-${w}-normal.woff2`, weight: String(w), range: BN},
    {family: 'Hind Siliguri', file: `fonts/hind-siliguri-latin-${w}-normal.woff2`, weight: String(w), range: LA},
  ]),
  ...[500, 700].map((w) => ({family: 'JetBrains Mono', file: `fonts/jetbrains-mono-latin-${w}-normal.woff2`, weight: String(w), range: LA})),
];

// অফলাইনে চলে: ফন্ট ফাইল public/fonts-এ
export const loadFonts = () => {
  if (typeof document === 'undefined') return;
  const handle = delayRender('fonts');
  Promise.all(
    specs.map(async (s) => {
      const f = new FontFace(s.family, `url(${staticFile(s.file)})`, {weight: s.weight, unicodeRange: s.range});
      await f.load();
      document.fonts.add(f);
    }),
  )
    .then(() => continueRender(handle))
    .catch((e) => {
      console.error('font load failed', e);
      continueRender(handle);
    });
};
