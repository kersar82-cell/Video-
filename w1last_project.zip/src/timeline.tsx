import React from 'react';
import {config} from './config';
import {theme} from './theme';
import {S01, S02, S03, S04, S05, S06, S07, S08} from './scenes/scenesA';
import {S09, S10, S11, S12, S13, S14, S15, S16, S17} from './scenes/scenesB';
import {S18, S19, S20, S21, S22, S23, S24, S25, S26, S27, S28} from './scenes/scenesC';

// সিনের শুরু (সেকেন্ড) — সব SRT cue-র সীমা থেকে; cue-র ভেতরের বিভাজন আনুপাতিক অনুমান
export const sceneList: {id: string; start: number; C: React.FC}[] = [
  {id: 'S01', start: 0, C: S01},
  {id: 'S02', start: 12.0, C: S02},
  {id: 'S03', start: 29.14, C: S03},
  {id: 'S04', start: 35.94, C: S04},
  {id: 'S05', start: 47.04, C: S05},
  {id: 'S06', start: 58.56, C: S06},
  {id: 'S07', start: 66.5, C: S07},
  {id: 'S08', start: 75.4, C: S08},
  {id: 'S09', start: 82.2, C: S09},
  {id: 'S10', start: 90.8, C: S10},
  {id: 'S11', start: 102.6, C: S11},
  {id: 'S12', start: 109.62, C: S12},
  {id: 'S13', start: 120.2, C: S13},
  {id: 'S14', start: 127.94, C: S14},
  {id: 'S15', start: 134.12, C: S15},
  {id: 'S16', start: 149.4, C: S16},
  {id: 'S17', start: 158.38, C: S17},
  {id: 'S18', start: 166.2, C: S18},
  {id: 'S19', start: 180.0, C: S19},
  {id: 'S20', start: 194.4, C: S20},
  {id: 'S21', start: 203.7, C: S21},
  {id: 'S22', start: 213.32, C: S22},
  {id: 'S23', start: 221.6, C: S23},
  {id: 'S24', start: 231.9, C: S24},
  {id: 'S25', start: 247.8, C: S25},
  {id: 'S26', start: 253.0, C: S26},
  {id: 'S27', start: 279.9, C: S27},
  {id: 'S28', start: 288.7, C: S28},
];

export const SRT_END = 290.82;
export const TOTAL_FRAMES = Math.ceil((SRT_END + config.tailSeconds) * theme.fps);

export const scenes = sceneList.map((s, i) => {
  const from = Math.round(s.start * theme.fps);
  const next = i + 1 < sceneList.length ? Math.round(sceneList[i + 1].start * theme.fps) : TOTAL_FRAMES;
  return {...s, from, dur: next - from, endSec: next / theme.fps};
});
