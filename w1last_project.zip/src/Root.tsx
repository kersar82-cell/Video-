import React from 'react';
import {AbsoluteFill, Audio, Composition, Sequence, staticFile} from 'remotion';
import {theme} from './theme';
import {loadFonts} from './fonts';
import {SceneCtx} from './components/primitives';
import {BgMesh, Grade, Grain, PreviewAudio, Vignette, Wipe} from './components/Stage';
import {TOTAL_FRAMES, scenes} from './timeline';

loadFonts();

export const Main: React.FC<{includeVoiceover?: boolean}> = ({includeVoiceover}) => (
  <AbsoluteFill style={{backgroundColor: theme.colors.bg, fontFamily: theme.fonts.display}}>
    <BgMesh />
    {scenes.map((s) => (
      <Sequence key={s.id} from={s.from} durationInFrames={s.dur} name={s.id}>
        <SceneCtx.Provider value={{startSec: s.from / theme.fps, endSec: s.endSec}}>
          <s.C />
        </SceneCtx.Provider>
      </Sequence>
    ))}
    {scenes.slice(1).map((s, i) => (
      <Sequence key={`w${s.id}`} from={Math.max(0, s.from - 7)} durationInFrames={16} name={`wipe-${s.id}`}>
        <Wipe />
        <Sequence from={0} layout="none">
          <Audio src={staticFile('sfx/swipe.wav')} volume={0.2} playbackRate={i % 2 === 0 ? 1 : 0.92} />
        </Sequence>
      </Sequence>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio includeVoiceover={includeVoiceover} />
  </AbsoluteFill>
);

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={theme.fps} width={theme.width} height={theme.height} defaultProps={{includeVoiceover: false}} />
);
