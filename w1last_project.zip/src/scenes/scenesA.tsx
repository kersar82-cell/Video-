import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme, rgba} from '../theme';
import {Abs, Character, Counter, Entrance, Float, GlassCard, KenBurns, LogoTile, SceneFrame, Sfx, Tag, WordReveal, bn, gradText, useT} from '../components/primitives';
import {Icon} from '../components/Icon';
import {CheckRow, Donut, PageTile, SpikeChart} from '../components/widgets';

const C = theme.colors;
const clamp01 = (n: number) => Math.min(Math.max(n, 0), 1);

/* S01 · হুক: নতুন ঘটনা + ব্যান্ডউইথ +৫০% · Kinetic Typography */
export const S01: React.FC = () => {
  const T = useT();
  const out1 = T(6.0, 0);
  return (
    <SceneFrame spot={{x: 960, y: 520, r: 1200}}>
      <Sfx t={0.25} n="whoosh" />
      <Sfx t={2.0} n="chime" />
      <Sfx t={9.8} n="pop" />
      <Abs x={0} y={230} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <WordReveal text="এবার একটা *নতুন ঘটনা" size={158} align="center" delay={2} per={5} outAt={out1} />
      </Abs>
      <Abs x={0} y={560} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(2.1)} outAt={out1}>
          <GlassCard style={{padding: '30px 52px', display: 'flex', alignItems: 'center', gap: 38}}>
            <LogoTile src="assets/wikimedia.jpg" w={140} radius={30} />
            <div>
              <div style={{fontSize: 58, fontWeight: 700, lineHeight: 1.25}}>উইকিমিডিয়া ফাউন্ডেশন</div>
              <div style={{fontSize: 36, color: C.textDim, fontWeight: 500, lineHeight: 1.4}}>নিজেদের ব্লগে · {bn('২০২৫')} সালের এপ্রিল</div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>

      <Abs x={0} y={120} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(6.4)}>
          <Tag text={`জানুয়ারি ${bn('২০২৪')} থেকে`} icon="calendar" size={36} />
        </Entrance>
      </Abs>
      <Abs x={0} y={230} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(8.0)}>
          <div style={{fontSize: 64, fontWeight: 600, color: C.textDim, lineHeight: 1.3}}>মাল্টিমিডিয়া ডাউনলোডের ব্যান্ডউইথ</div>
        </Entrance>
      </Abs>
      <Abs x={0} y={340} w={1920} style={{display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 40}}>
        <Entrance delay={T(9.6)} cfg="bouncy" style={{display: 'flex', alignItems: 'center', gap: 36}}>
          <Float amp={8}>
            <Icon n="arrowUp" size={210} color={C.accent} stroke={2.4} />
          </Float>
          <div style={{fontSize: 400, fontWeight: 700, lineHeight: 1.05, ...gradText, filter: `drop-shadow(0 0 50px ${rgba('primary', 0.55)})`}}>
            +<Counter to={50} delay={T(9.7)} format={(v) => bn(Math.round(v))} />%
          </div>
        </Entrance>
      </Abs>
      <Abs x={0} y={800} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(10.8)}>
          <div style={{fontSize: 52, fontWeight: 600, letterSpacing: 0}}>
            <span style={{color: C.accent}}>৫০ শতাংশ</span> বেড়েছে
          </div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S02 · বট স্ক্র্যাপিং · Hub and Spoke */
export const S02: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const cx = 600;
  const cy = 690;
  const R = 270;
  const bots = Array.from({length: 6}).map((_, i) => {
    const a = (Math.PI * 2 * i) / 6 - Math.PI / 2;
    return {x: cx + Math.cos(a) * R, y: cy + Math.sin(a) * R, i};
  });
  return (
    <SceneFrame spot={{x: 620, y: 690, r: 1100}}>
      <Sfx t={15.0} n="pop" />
      <Sfx t={18.1} n="chime" />
      <Sfx t={23.3} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="উইকিমিডিয়া কমন্স" icon="image" /></Entrance>
      </Abs>
      <Abs x={110} y={160} w={1500}>
        <WordReveal text="এই বৃদ্ধি *মানুষ থেকে আসেনি" size={78} delay={T(12.2)} outAt={T(14.5, 0)} />
      </Abs>
      <Abs x={110} y={160} w={1500}>
        <WordReveal text="এসেছে *স্বয়ংক্রিয় প্রোগ্রাম থেকে" size={78} delay={T(14.8)} />
      </Abs>

      {/* স্পোক লাইন + প্যাকেট */}
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        {bots.map((b) => {
          const d = T(15.4) + b.i * 4;
          const lp = clamp01((frame - d) / 14);
          const u = ((frame - d) / 44 + b.i * 0.17) % 1;
          return (
            <g key={b.i} opacity={lp}>
              <line x1={cx} y1={cy} x2={cx + (b.x - cx) * lp} y2={cy + (b.y - cy) * lp} stroke={rgba('accent', 0.35)} strokeWidth={3} strokeDasharray="10 10" />
              {lp >= 1 && frame > T(18.0) && <circle cx={cx + (b.x - cx) * u} cy={cy + (b.y - cy) * u} r={9} fill={C.accent} />}
            </g>
          );
        })}
      </svg>
      <Abs x={cx - 170} y={cy - 190}>
        <Entrance delay={T(17.6)} cfg="bouncy">
          <GlassCard hero style={{width: 340, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22}}>
            <LogoTile src="assets/wikimedia.jpg" w={190} radius={34} />
            <div style={{fontSize: 38, fontWeight: 700, textAlign: 'center', lineHeight: 1.25}}>Wikimedia<br />Commons</div>
          </GlassCard>
        </Entrance>
      </Abs>
      {bots.map((b) => (
        <Abs key={b.i} x={b.x - 56} y={b.y - 56}>
          <Entrance delay={T(15.2) + b.i * 4} cfg="bouncy" from={0.5}>
            <Float amp={5} phase={b.i}>
              <div style={{width: 112, height: 112, borderRadius: 36, background: C.surface, border: `2px solid ${rgba('accent', 0.5)}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <Icon n="bot" size={62} color={C.accent} />
              </div>
            </Float>
          </Entrance>
        </Abs>
      ))}

      {/* ডান: এআই + ফাইল কাউন্টার */}
      <Abs x={1180} y={330} w={640}>
        <Entrance delay={T(17.7)} dx={60} dy={0}>
          <GlassCard style={{padding: '28px 36px', display: 'flex', alignItems: 'center', gap: 26}}>
            <Icon n="chip" size={74} color={C.accent} />
            <div>
              <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.25}}>এআই মডেলের জন্য</div>
              <div style={{fontSize: 36, color: C.textDim, fontWeight: 500, lineHeight: 1.35}}>ছবি জোগাতে স্ক্র্যাপ</div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1180} y={590} w={640}>
        <Entrance delay={T(23.2)} dx={60} dy={0}>
          <GlassCard hero style={{padding: '36px 40px'}}>
            <div style={{fontSize: 34, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>কমন্সে তখন ফাইল ছিল</div>
            <div style={{fontSize: 118, fontWeight: 700, lineHeight: 1.15, ...gradText}}>
              <Counter to={14} delay={T(23.4)} format={(v) => bn(Math.round(v))} />
              <span style={{fontSize: 64}}> কোটি ৪০ লাখ</span>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S03 · ৬৫% বনাম ৩৫% · Data Dashboard (ডোনাট) */
export const S03: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 520, y: 600, r: 900}}>
      <Sfx t={29.5} n="pop" />
      <Sfx t={32.7} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="টেক ক্রাঞ্চের প্রতিবেদন অনুযায়ী" icon="doc" /></Entrance>
      </Abs>
      <Abs x={110} y={160} w={1700}>
        <WordReveal text="সবচেয়ে *ব্যয়বহুল ট্রাফিক" size={84} delay={4} />
      </Abs>
      <Abs x={290} y={330}>
        <Entrance delay={T(29.4)} cfg="bouncy" from={0.8}>
          <Donut pct={65} size={470} delay={T(29.5)} color={C.primary} hero thick={40}>
            <div style={{fontSize: 150, fontWeight: 700, lineHeight: 1.1, ...gradText}}>{bn(65)}%</div>
          </Donut>
        </Entrance>
      </Abs>
      <Abs x={150} y={830} w={750} style={{textAlign: 'center'}}>
        <Entrance delay={T(30.2)}>
          <div style={{fontSize: 46, fontWeight: 600, lineHeight: 1.3}}>ব্যয়বহুল ট্রাফিকে <span style={{color: C.accent}}>বটের ভাগ</span></div>
        </Entrance>
      </Abs>
      <Abs x={875} y={560}>
        <Entrance delay={T(32.2)} cfg="snappy"><Tag text="অথচ" tone="dim" size={40} /></Entrance>
      </Abs>
      <Abs x={1170} y={330}>
        <Entrance delay={T(32.6)} cfg="bouncy" from={0.8}>
          <Donut pct={35} size={470} delay={T(32.7)} color={C.accent} thick={40}>
            <div style={{fontSize: 150, fontWeight: 700, lineHeight: 1.1}}>{bn(35)}%</div>
          </Donut>
        </Entrance>
      </Abs>
      <Abs x={1020} y={830} w={770} style={{textAlign: 'center'}}>
        <Entrance delay={T(33.6)}>
          <div style={{fontSize: 46, fontWeight: 600, lineHeight: 1.3}}>মোট পেজ ভিউয়ে <span style={{color: C.accent}}>বটের ভাগ মাত্র</span></div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S04 · কেন? মানুষ বনাম ক্রলার · Before/After Split */
export const S04: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const popular = [1, 2, 6];
  const Grid: React.FC<{mode: 'human' | 'bot'; start: number}> = ({mode, start}) => (
    <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 86px)', gap: 26, justifyContent: 'center'}}>
      {Array.from({length: 12}).map((_, i) => {
        const lit = mode === 'human' ? (popular.includes(i) ? 1 : 0) : clamp01((frame - start - i * 3) / 6);
        const pulse = mode === 'human' && popular.includes(i) ? 1 : lit;
        return <PageTile key={i} lit={pulse} hero={mode === 'human' && popular.includes(i) && i === 2} />;
      })}
    </div>
  );
  return (
    <SceneFrame spot={{x: 1400, y: 560, c: 'accent', r: 900, o: 0.35}}>
      <Sfx t={36.6} n="pop" />
      <Sfx t={41.4} n="pop" />
      <Sfx t={44.9} n="click" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="কারণ হিসেবে তারা বলেছে" icon="search" /></Entrance>
      </Abs>
      <Abs x={110} y={235}>
        <Entrance delay={T(36.2)}>
          <GlassCard style={{width: 820, height: 700, padding: '34px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 30}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 18}}>
              <Icon n="user" size={58} color={C.text} />
              <span style={{fontSize: 56, fontWeight: 700}}>মানুষ</span>
            </div>
            <Grid mode="human" start={0} />
            <div style={{fontSize: 42, fontWeight: 600, textAlign: 'center', lineHeight: 1.35, padding: '0 40px'}}>প্রায় একই <span style={{color: C.accent}}>জনপ্রিয় বিষয়</span> পড়ে</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={990} y={235}>
        <Entrance delay={T(41.2)}>
          <GlassCard hero style={{width: 820, height: 700, padding: '34px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 30}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 18}}>
              <Icon n="bot" size={58} color={C.accent} />
              <span style={{fontSize: 56, fontWeight: 700}}>ক্রলার</span>
            </div>
            <Grid mode="bot" start={T(41.9)} />
            <div style={{fontSize: 42, fontWeight: 600, textAlign: 'center', lineHeight: 1.35, padding: '0 40px'}}>একসাথে <span style={{color: C.accent}}>অনেক পেজ</span>, কম জনপ্রিয় পেজও</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={990} y={955} w={820}>
        <Entrance delay={T(44.8)}>
          <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 24, fontSize: 40, fontWeight: 600}}>
            <Icon n="server" size={52} color={C.accent} />
            <span>মূল ডেটা সেন্টার থেকে আনতে হয়</span>
          </div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S05 · জিমি কার্টার · Glass Cards + কাউন্টার */
export const S05: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 1250, y: 560, r: 1000}}>
      <Sfx t={49.7} n="chime" />
      <Sfx t={54.9} n="pop" />
      <Abs x={140} y={110} w={560}>
        <Entrance delay={T(49.4)} dy={50}>
          <GlassCard style={{padding: 18, width: 560}}>
            <div style={{width: 524, height: 640, borderRadius: 22, overflow: 'hidden'}}>
              <KenBurns src="assets/carter-portrait.jpg" zoomTo={1.1} panX={0} />
            </div>
            <div style={{padding: '22px 14px 8px', fontSize: 42, fontWeight: 700, lineHeight: 1.3}}>জিমি কার্টার</div>
            <div style={{padding: '0 14px 12px', fontSize: 32, color: C.textDim, fontWeight: 500}}>মারা যান ডিসেম্বর {bn('২০২৪')}</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={800} y={160}>
        <Entrance delay={T(47.3)}><Tag text="একটা বাস্তব ঘটনা" icon="clock" size={34} /></Entrance>
      </Abs>
      <Abs x={800} y={270} w={1000}>
        <WordReveal text="ইংরেজি উইকিপিডিয়ায় তার পেজ *একদিনে" size={72} delay={T(52.9)} per={3} />
      </Abs>
      <Abs x={800} y={490} w={1010}>
        <Entrance delay={T(54.6)} cfg="bouncy" from={0.85}>
          <GlassCard hero style={{padding: '30px 48px', display: 'inline-flex', alignItems: 'center', gap: 36}}>
            <Icon n="eye" size={110} color={C.accent} />
            <div>
              <div style={{fontSize: 190, fontWeight: 700, lineHeight: 1.05, ...gradText}}>
                <Counter to={28} delay={T(54.7)} format={(v) => bn(Math.round(v))} />
                <span style={{fontSize: 100}}> লাখ+</span>
              </div>
              <div style={{fontSize: 40, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>বার দেখা হয়েছে</div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S06 · ডিবেট ভিডিও → ২× ট্রাফিক · Line Chart */
export const S06: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 1250, y: 520, c: 'accent', r: 1000, o: 0.35}}>
      <Sfx t={59.2} n="pop" />
      <Sfx t={64.5} n="pop" v={0.34} />
      <Abs x={110} y={100}>
        <Entrance delay={T(58.7)} dy={50}>
          <GlassCard style={{width: 600, padding: 16}}>
            <div style={{position: 'relative', width: 568, height: 568, borderRadius: 22, overflow: 'hidden'}}>
              <KenBurns src="assets/carter-podium.jpg" zoomTo={1.12} panX={-10} />
              <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 180, background: 'linear-gradient(180deg, transparent, rgba(8,14,27,0.92))'}} />
              <div style={{position: 'absolute', left: 24, bottom: 22, display: 'flex', alignItems: 'center', gap: 16}}>
                <div style={{width: 64, height: 64, borderRadius: 32, background: C.primary, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                  <Icon n="play" size={34} color={C.text} fill={C.text} stroke={1} />
                </div>
                <span style={{fontSize: 38, fontWeight: 700, lineHeight: 1.2}}>দেড় ঘণ্টার ভিডিও</span>
              </div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={110} y={760}>
        <Entrance delay={T(59.8)}><Tag text={`${bn('১৯৮০')} সালের ডিবেট`} icon="play" size={36} /></Entrance>
      </Abs>
      <Abs x={780} y={110}>
        <Entrance delay={T(60.8)}>
          <div style={{display: 'flex', alignItems: 'center', gap: 20}}>
            <Icon n="wifi" size={56} color={C.accent} />
            <span style={{fontSize: 56, fontWeight: 700}}>নেটওয়ার্ক ট্রাফিক</span>
          </div>
        </Entrance>
      </Abs>
      <Abs x={780} y={230}>
        <Entrance delay={T(61.4)}>
          <GlassCard style={{width: 880, height: 600, padding: '40px 40px 50px'}}>
            <SpikeChart w={800} h={500} delay={T(61.6)} spikeDelay={T(64.3)} />
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={880} y={620}>
        <Entrance delay={T(62.5)}><Tag text="স্বাভাবিক" tone="dim" size={30} /></Entrance>
      </Abs>
      <Abs x={1300} y={262}>
        <Entrance delay={T(64.5)} cfg="bouncy" from={0.5}>
          <div style={{padding: '4px 36px 12px', borderRadius: 28, background: C.primary, boxShadow: `0 0 60px ${rgba('primary', 0.7)}`, fontSize: 96, fontWeight: 700, lineHeight: 1.2}}>{bn(2)}×</div>
        </Entrance>
      </Abs>
      <Abs x={780} y={860}>
        <Entrance delay={T(64.9)}><div style={{fontSize: 50, fontWeight: 700}}>স্বাভাবিকের <span style={{color: C.accent}}>দ্বিগুণ</span></div></Entrance>
      </Abs>
      <Character pose="shock" h={400} delay={T(64.8)} style={{left: 1690, top: 640}} />
    </SceneFrame>
  );
};

/* S07 · সংযোগ ভরে গেল → ঠিক হলো · Timeline */
export const S07: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const items = [
    {t: 66.6, icon: 'wifi', title: 'প্রায় এক ঘণ্টা', sub: 'কিছু ইন্টারনেট সংযোগ পুরো ভরে গেল'},
    {t: 68.9, icon: 'clock', title: 'কিছু ইউজারের পেজ', sub: 'ধীরে লোড হলো'},
    {t: 71.7, icon: 'route', title: 'এসআরই টিম', sub: 'নেটওয়ার্কের রুট বদলাল'},
    {t: 74.3, icon: 'check', title: 'সমস্যা ঠিক হলো', sub: ''},
  ];
  const y0 = 170;
  const gap = 210;
  const lineP = clamp01((frame - T(66.8)) / (T(74.3) - T(66.8)));
  // লিংক লোড বার: প্রথমটি ভরে, তারপর রুট বদলে ভাগ হয়
  const l1 = interpolate(frame, [T(66.7), T(68.0), T(71.8), T(73.4)], [0.05, 1, 1, 0.55], {easing: theme.ease.inOut, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const l2 = interpolate(frame, [T(71.8), T(73.4)], [0.12, 0.5], {easing: theme.ease.inOut, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <SceneFrame spot={{x: 1350, y: 540, r: 1000, o: 0.4}}>
      <Sfx t={68.9} n="click" />
      <Sfx t={71.7} n="click" />
      <Sfx t={74.3} n="success" />
      <div style={{position: 'absolute', left: 168, top: y0 + 50, width: 6, height: gap * 3, borderRadius: 3, background: rgba('text', 0.10)}} />
      <div style={{position: 'absolute', left: 168, top: y0 + 50, width: 6, height: gap * 3 * lineP, borderRadius: 3, background: `linear-gradient(180deg, ${C.accent}, ${C.primary})`, boxShadow: `0 0 20px ${rgba('primary', 0.6)}`}} />
      {items.map((it, i) => (
        <Abs key={i} x={110} y={y0 + i * gap}>
          <Entrance delay={T(it.t)} dx={-50} dy={0}>
            <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
              <div style={{width: 120, height: 120, borderRadius: 60, background: i === 3 ? rgba('success', 0.18) : C.surface, border: `2.5px solid ${i === 3 ? C.success : rgba('accent', 0.55)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: i === 2 ? `0 0 50px ${rgba('primary', 0.55)}` : undefined, flexShrink: 0}}>
                <Icon n={it.icon} size={62} color={i === 3 ? C.success : C.accent} stroke={2.2} />
              </div>
              <div>
                <div style={{fontSize: 62, fontWeight: 700, lineHeight: 1.25}}>{it.title}</div>
                {it.sub && <div style={{fontSize: 40, fontWeight: 500, color: C.textDim, lineHeight: 1.35}}>{it.sub}</div>}
              </div>
            </div>
          </Entrance>
        </Abs>
      ))}
      <Abs x={1060} y={250}>
        <Entrance delay={T(66.9)} dx={60} dy={0}>
          <GlassCard style={{width: 740, padding: '44px 48px'}}>
            <div style={{fontSize: 40, fontWeight: 700, marginBottom: 36, display: 'flex', alignItems: 'center', gap: 16}}>
              <Icon n="gauge" size={46} color={C.accent} />ইন্টারনেট সংযোগের লোড
            </div>
            {[{n: 'সংযোগ ১', v: l1, hero: true}, {n: 'সংযোগ ২', v: l2, hero: false}].map((b, i) => (
              <div key={i} style={{marginBottom: 34}}>
                <div style={{fontSize: 34, color: C.textDim, fontWeight: 600, marginBottom: 12}}>{b.n}</div>
                <div style={{height: 38, borderRadius: 19, background: rgba('text', 0.09), overflow: 'hidden'}}>
                  <div style={{width: `${b.v * 100}%`, height: '100%', borderRadius: 19, background: b.hero ? `linear-gradient(90deg, ${C.accent}, ${C.primary})` : C.accent, boxShadow: b.hero && b.v > 0.9 ? `0 0 30px ${rgba('primary', 0.8)}` : undefined}} />
                </div>
              </div>
            ))}
            <div style={{fontSize: 34, color: C.textDim, fontWeight: 500, lineHeight: 1.4}}>রুট বদলে চাপ ভাগ হলো</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S08 · ক্রলার আটকানো · Gate / Shield */
export const S08: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const shieldX = 800;
  const rows = [470, 640, 810];
  const pulse = (Math.sin(frame / 10) + 1) / 2;
  return (
    <SceneFrame spot={{x: 800, y: 640, r: 900}}>
      <Sfx t={76.6} n="pop" />
      <Sfx t={80.2} n="chime" v={0.2} />
      <Abs x={110} y={90} w={1700}>
        <WordReveal text="এসআরই টিমকে প্রায়ই *ক্রলার আটকাতে হচ্ছে" size={78} delay={T(75.6)} per={3} />
      </Abs>
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        {rows.map((y, i) => {
          const u = ((frame - T(76.3)) / 58 + i * 0.31) % 1;
          const uu = Math.max(u, 0);
          const hit = uu < 0.62;
          const x = hit ? 210 + (shieldX - 130 - 210) * theme.ease.out(uu / 0.62) : shieldX - 130 - 150 * ((uu - 0.62) / 0.38);
          return <g key={i} opacity={clamp01((frame - T(76.3)) / 10)}><circle cx={x} cy={y} r={8} fill={C.accent} opacity={0.7} /><circle cx={x - 40} cy={y} r={5} fill={C.accent} opacity={0.35} /></g>;
        })}
        {frame > T(77.4) && [0, 1, 2, 3, 4].map((i) => {
          const u = ((frame - T(77.4)) / 40 + i * 0.2) % 1;
          return <circle key={i} cx={shieldX + 150 + u * 480} cy={640} r={9} fill={C.success} opacity={1 - Math.abs(u - 0.5) * 0.6} />;
        })}
      </svg>
      {rows.map((y, i) => (
        <Abs key={i} x={110} y={y - 50}>
          <Entrance delay={T(76.3) + i * 4} from={0.5} cfg="bouncy">
            <div style={{width: 100, height: 100, borderRadius: 32, background: C.surface, border: `2px solid ${rgba('accent', 0.5)}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <Icon n="bot" size={56} color={C.accent} />
            </div>
          </Entrance>
        </Abs>
      ))}
      <Abs x={shieldX - 130} y={640 - 175}>
        <Entrance delay={T(76.6)} cfg="bouncy" from={0.6}>
          <div style={{width: 260, height: 350, display: 'flex', alignItems: 'center', justifyContent: 'center', filter: `drop-shadow(0 0 ${30 + pulse * 30}px ${rgba('primary', 0.8)})`}}>
            <Icon n="shield" size={300} color={C.primary} stroke={1.6} />
          </div>
        </Entrance>
      </Abs>
      <Abs x={1440} y={570}>
        <Entrance delay={T(77.4)} cfg="bouncy" from={0.5}>
          <div style={{width: 150, height: 150, borderRadius: 44, background: rgba('success', 0.14), border: `2.5px solid ${C.success}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Icon n="user" size={86} color={C.success} />
          </div>
        </Entrance>
      </Abs>
      <Abs x={1230} y={760} w={560} style={{textAlign: 'center'}}>
        <Entrance delay={T(80.0)}>
          <div style={{fontSize: 44, fontWeight: 600, lineHeight: 1.35}}>সাধারণ পাঠকের <span style={{color: C.success}}>অসুবিধা না হয়</span></div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};
