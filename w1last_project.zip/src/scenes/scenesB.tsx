import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, rgba} from '../theme';
import {Abs, Counter, Entrance, Float, GlassCard, LogoTile, SceneFrame, Sfx, Tag, WordReveal, bn, bnInt, gradText, useT} from '../components/primitives';
import {Icon} from '../components/Icon';
import {Donut, Gauge, Globe, QueuePipe} from '../components/widgets';

const C = theme.colors;
const clamp01 = (n: number) => Math.min(Math.max(n, 0), 1);

/* S09 · AWS পরিচিতি + প্রাইম ডে ক্যালেন্ডার · Statement + Calendar */
export const S09: React.FC = () => {
  const T = useT();
  const days = [{d: '২৩', t: 88.4}, {d: '২৪', t: 88.8}, {d: '২৫', t: 89.2}, {d: '২৬', t: 89.7}];
  return (
    <SceneFrame spot={{x: 1100, y: 700, r: 1100}}>
      <Sfx t={82.9} n="chime" />
      <Sfx t={88.4} n="pop" />
      <Abs x={140} y={250}>
        <Entrance delay={T(82.7)} cfg="bouncy" from={0.8}>
          <Float amp={7}><LogoTile src="assets/aws.jpg" w={400} radius={46} /></Float>
        </Entrance>
      </Abs>
      <Abs x={640} y={150}>
        <Entrance delay={T(82.4)}><Tag text="এডব্লিউএস · প্রতি বছর" icon="cloud" size={34} /></Entrance>
      </Abs>
      <Abs x={640} y={250} w={1150}>
        <WordReveal text="প্রাইম ডের পর ব্লগে *সংখ্যা প্রকাশ করে" size={80} delay={T(83.4)} per={3} />
      </Abs>
      <Abs x={640} y={560} w={1170}>
        <Entrance delay={T(87.0)} dy={50}>
          <GlassCard hero style={{padding: '34px 44px'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 22, marginBottom: 26}}>
              <Icon n="calendar" size={58} color={C.accent} />
              <span style={{fontSize: 52, fontWeight: 700}}>প্রাইম ডে {bn('২০২৬')}</span>
              <span style={{fontSize: 40, color: C.textDim, fontWeight: 600}}>· জুন</span>
            </div>
            <div style={{display: 'flex', gap: 26}}>
              {days.map((d, i) => (
                <Entrance key={i} delay={T(d.t)} cfg="bouncy" from={0.6} style={{flex: 1}}>
                  <div style={{height: 150, borderRadius: 26, background: i === 0 ? C.primary : rgba('primary', 0.35), border: `2px solid ${rgba('accent', 0.5)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 96, fontWeight: 700, lineHeight: 1.2}}>{d.d}</div>
                </Entrance>
              ))}
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S10 · ডাইনামো ডিবি · Bento Grid */
export const S10: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 640, y: 520, r: 1000}}>
      <Sfx t={91.1} n="chime" />
      <Sfx t={94.0} n="pop" />
      <Sfx t={98.4} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="AWS ব্লগ অনুযায়ী" icon="doc" /></Entrance>
      </Abs>
      {/* বড় কার্ড: DynamoDB */}
      <Abs x={110} y={190}>
        <Entrance delay={T(90.9)} dy={40}>
          <GlassCard style={{width: 640, height: 780, padding: 40, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 28}}>
            <LogoTile src="assets/dynamodb.jpg" w={560} h={315} fit="cover" bg={C.surface} radius={26} />
            <div style={{fontSize: 64, fontWeight: 700, lineHeight: 1.25}}>DynamoDB</div>
            <div style={{display: 'flex', alignItems: 'center', gap: 14, fontSize: 42, fontWeight: 600, color: C.textDim}}>
              <Icon n="database" size={48} color={C.accent} /> ডেটাবেস
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      {/* চালায়: Amazon.com / Alexa / ফুলফিলমেন্ট */}
      <Abs x={790} y={190}>
        <Entrance delay={T(93.8)} dy={40}>
          <GlassCard style={{width: 480, height: 370, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
            <LogoTile src="assets/amazon.jpg" w={190} radius={40} />
            <div style={{fontSize: 46, fontWeight: 700}}>Amazon.com</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1310} y={190}>
        <Entrance delay={T(95.0)} dy={40}>
          <GlassCard style={{width: 500, height: 370, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
            <div style={{width: 160, height: 160, borderRadius: 80, border: `10px solid ${C.accent}`, boxShadow: `0 0 40px ${rgba('accent', 0.4)}`}} />
            <div style={{fontSize: 46, fontWeight: 700}}>Alexa</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={790} y={590}>
        <Entrance delay={T(96.2)} dy={40}>
          <GlassCard style={{width: 480, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
            <Icon n="box" size={130} color={C.accent} stroke={1.5} />
            <div style={{fontSize: 42, fontWeight: 700, textAlign: 'center', lineHeight: 1.3}}>সব ফুলফিলমেন্ট<br />সেন্টারের সিস্টেম</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1310} y={590}>
        <Entrance delay={T(98.3)} dy={40} cfg="bouncy" from={0.88}>
          <GlassCard hero style={{width: 500, height: 380, padding: '30px 34px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
            <div style={{fontSize: 34, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>চার দিনে</div>
            <div style={{fontSize: 130, fontWeight: 700, lineHeight: 1.1, ...gradText}}>
              <Counter to={59} delay={T(98.5)} format={(v) => bn(Math.round(v))} />
              <span style={{fontSize: 56}}> ট্রিলিয়ন+</span>
            </div>
            <div style={{fontSize: 38, fontWeight: 600, lineHeight: 1.3}}>রিকোয়েস্ট</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S11 · ১৯ কোটি ২০ লাখ/সেকেন্ড · Glossy Gauge */
export const S11: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 760, y: 600, r: 1000}}>
      <Sfx t={103.3} n="pop" />
      <Sfx t={107.1} n="click" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="সর্বোচ্চ · প্রতি সেকেন্ডে" icon="gauge" /></Entrance>
      </Abs>
      <Abs x={110} y={200}>
        <Entrance delay={T(103.2)} cfg="bouncy" from={0.85}>
          <GlassCard hero style={{width: 880, height: 700, display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 70}}>
            <Gauge delay={T(103.4)} size={640} level={0.9} />
            <div style={{marginTop: 20, textAlign: 'center'}}>
              <div style={{fontSize: 118, fontWeight: 700, lineHeight: 1.1, ...gradText}}>
                <Counter to={19.2} decimals={1} delay={T(103.6)} format={(v) => bn(v.toFixed(1))} />
                <span style={{fontSize: 58}}> কোটি</span>
              </div>
              <div style={{fontSize: 40, fontWeight: 600, color: C.textDim, lineHeight: 1.4}}>রিকোয়েস্ট প্রতি সেকেন্ডে</div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1070} y={330}>
        <Entrance delay={T(106.9)} dx={70} dy={0}>
          <GlassCard style={{width: 740, padding: '44px 50px'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 22}}>
              <Icon n="bolt" size={90} color={C.accent} stroke={1.6} />
              <div>
                <div style={{fontSize: 38, fontWeight: 600, color: C.textDim, lineHeight: 1.3}}>রেসপন্স এসেছে</div>
                <div style={{fontSize: 64, fontWeight: 700, lineHeight: 1.3}}>এক অঙ্কের <span style={{color: C.accent}}>মিলিসেকেন্ডে</span></div>
              </div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S12 · ElastiCache · Dashboard cards */
export const S12: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 1100, y: 600, r: 1100}}>
      <Sfx t={110.2} n="chime" />
      <Sfx t={112.0} n="pop" />
      <Sfx t={116.2} n="pop" />
      <Abs x={110} y={200}>
        <Entrance delay={T(109.8)} dy={40}>
          <GlassCard style={{width: 560, height: 640, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28}}>
            <Float amp={8}><Icon n="layers" size={210} color={C.accent} stroke={1.3} /></Float>
            <div style={{fontSize: 66, fontWeight: 700, lineHeight: 1.25}}>ElastiCache</div>
            <div style={{fontSize: 42, fontWeight: 600, color: C.textDim, lineHeight: 1.3}}>ক্যাশ সার্ভিস</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={730} y={200}>
        <Entrance delay={T(111.9)} dx={60} dy={0} cfg="bouncy" from={0.9}>
          <GlassCard hero style={{width: 1080, height: 300, padding: '28px 48px', display: 'flex', alignItems: 'center', gap: 34}}>
            <Icon n="calendar" size={88} color={C.accent} />
            <div>
              <div style={{fontSize: 38, fontWeight: 600, color: C.textDim, lineHeight: 1.3}}>সর্বোচ্চ একদিনে</div>
              <div style={{fontSize: 112, fontWeight: 700, lineHeight: 1.12, ...gradText}}>
                <Counter to={2.3} decimals={1} delay={T(112.2)} format={(v) => bn(v.toFixed(1))} />
                <span style={{fontSize: 56}}> কোয়াড্রিলিয়ন+</span>
              </div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={730} y={540}>
        <Entrance delay={T(116.0)} dx={60} dy={0} cfg="bouncy" from={0.9}>
          <GlassCard style={{width: 1080, height: 300, padding: '28px 48px', display: 'flex', alignItems: 'center', gap: 34}}>
            <Icon n="clock" size={88} color={C.accent} />
            <div>
              <div style={{fontSize: 38, fontWeight: 600, color: C.textDim, lineHeight: 1.3}}>এক মিনিটে</div>
              <div style={{fontSize: 112, fontWeight: 700, lineHeight: 1.12}}>
                <Counter to={2.1} decimals={1} delay={T(116.4)} format={(v) => bn(v.toFixed(1))} />
                <span style={{fontSize: 56}}> ট্রিলিয়ন</span>
              </div>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={730} y={880}>
        <Entrance delay={T(110.4)}><Tag text="রিকোয়েস্ট পেয়েছে" icon="arrowRight" size={34} tone="dim" /></Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S13 · CloudFront সিডিএন · Hub (গ্লোব) */
export const S13: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 560, y: 560, r: 1000}}>
      <Sfx t={120.5} n="chime" />
      <Sfx t={123.4} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="CloudFront · AWS-এর সিডিএন" icon="globe" /></Entrance>
      </Abs>
      <Abs x={150} y={200}>
        <Globe size={700} delay={T(120.4)} />
      </Abs>
      <Abs x={940} y={250} w={880}>
        <Entrance delay={T(122.2)}><Tag text="প্রাইম ডের গ্লোবাল সপ্তাহে" icon="calendar" tone="dim" size={34} /></Entrance>
      </Abs>
      <Abs x={940} y={370}>
        <Entrance delay={T(123.2)} cfg="bouncy" from={0.88}>
          <GlassCard hero style={{width: 880, padding: '40px 50px'}}>
            <div style={{fontSize: 40, fontWeight: 600, color: C.textDim, lineHeight: 1.3}}>সামলেছে</div>
            <div style={{fontSize: 150, fontWeight: 700, lineHeight: 1.1, ...gradText}}>
              <Counter to={2.1} decimals={1} delay={T(123.4)} format={(v) => bn(v.toFixed(1))} />
              <span style={{fontSize: 66}}> ট্রিলিয়ন+</span>
            </div>
            <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.3}}>এইচটিটিপি রিকোয়েস্ট</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S14 · SQS · Queue flow */
export const S14: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 960, y: 520, r: 1200}}>
      <Sfx t={128.4} n="chime" />
      <Sfx t={131.2} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="SQS · মেসেজ কিউ সার্ভিস" icon="queue" /></Entrance>
      </Abs>
      <Abs x={110} y={170} w={1700}>
        <WordReveal text="সর্বোচ্চ *প্রতি সেকেন্ডে" size={84} delay={T(128.3)} />
      </Abs>
      <Abs x={110} y={400}>
        <QueuePipe w={1700} delay={T(128.8)} />
      </Abs>
      <Abs x={110} y={660} w={1700} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(131.0)} cfg="bouncy" from={0.88}>
          <div style={{fontSize: 190, fontWeight: 700, lineHeight: 1.1, ...gradText, filter: `drop-shadow(0 0 40px ${rgba('primary', 0.5)})`}}>
            <Counter to={21} delay={T(131.2)} format={(v) => bn(Math.round(v))} />
            <span style={{fontSize: 80}}> কোটি ৩০ লাখ মেসেজ</span>
          </div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S15 · ফল্ট ইনজেকশন · Before/After বার */
export const S15: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const barMax = 480;
  const pBig = clamp01(spring({frame: frame - T(135.6), fps, config: {damping: 24, stiffness: 50, mass: 1}}));
  const pSmall = clamp01(spring({frame: frame - T(142.3), fps, config: theme.spring.snappy}));
  return (
    <SceneFrame spot={{x: 1250, y: 560, r: 1100}}>
      <Sfx t={135.6} n="pop" />
      <Sfx t={139.6} n="chime" />
      <Sfx t={146.4} n="success" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="ফল্ট ইনজেকশন সার্ভিস" icon="flask" /></Entrance>
      </Abs>
      <Abs x={110} y={170} w={800}>
        <WordReveal text="ব্যর্থতার *পরীক্ষা আগেভাগেই" size={70} delay={T(134.6)} />
      </Abs>
      <Abs x={110} y={420} w={760}>
        <Entrance delay={T(139.5)} cfg="bouncy" from={0.8}>
          <GlassCard style={{padding: '28px 36px', display: 'inline-flex', alignItems: 'center', gap: 24}}>
            <Icon n="arrowUp" size={70} color={C.success} stroke={2.2} />
            <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.3}}>২০২৫-এর <span style={{color: C.accent}}>ছয় গুণের বেশি</span></div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={110} y={700} w={760}>
        <Entrance delay={T(146.0)} dx={-40} dy={0}>
          <GlassCard style={{padding: '30px 36px', display: 'flex', alignItems: 'center', gap: 26}}>
            <Icon n="shield" size={80} color={C.success} />
            <div style={{fontSize: 44, fontWeight: 700, lineHeight: 1.35}}>উদ্দেশ্য: প্রাইম ডেতে <span style={{color: C.accent}}>Amazon.com</span> যেন চালু থাকে</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={990} y={140}>
        <Entrance delay={T(135.2)}>
          <GlassCard style={{width: 830, height: 860}}>
            <div style={{position: 'absolute', left: 90, right: 90, bottom: 120, height: barMax + 130}}>
              {/* ২০২৪ বার */}
              <div style={{position: 'absolute', left: 30, bottom: 0, width: 230}}>
                <div style={{textAlign: 'center', fontSize: 62, fontWeight: 700, opacity: pSmall, lineHeight: 1.3}}>{bn(733)}</div>
                <div style={{height: Math.max(barMax * (733 / 44000) * pSmall, 4), borderRadius: 14, background: rgba('text', 0.55)}} />
              </div>
              {/* ২০২৬ বার */}
              <div style={{position: 'absolute', right: 30, bottom: 0, width: 230}}>
                <div style={{textAlign: 'center', fontSize: 62, fontWeight: 700, lineHeight: 1.3, opacity: pBig, ...gradText}}>{bnInt(44000 * pBig)}+</div>
                <div style={{height: barMax * pBig, borderRadius: 16, background: `linear-gradient(180deg, ${C.accent}, ${C.primary})`, boxShadow: `0 0 70px ${rgba('primary', 0.7)}`}} />
              </div>
            </div>
            <div style={{position: 'absolute', left: 120, bottom: 52, fontSize: 36, fontWeight: 600, color: C.textDim, opacity: pSmall, lineHeight: 1.3}}>২০২৪-এর পোস্টে</div>
            <div style={{position: 'absolute', right: 110, bottom: 52, fontSize: 36, fontWeight: 600, color: C.text, opacity: pBig, lineHeight: 1.3}}>২০২৬-এর পোস্টে</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S16 · Graviton ৪৯% · Chip + Donut */
export const S16: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 1300, y: 560, r: 1000}}>
      <Sfx t={149.9} n="chime" />
      <Sfx t={152.2} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text={`Graviton · ${bn('২০২৬')} এ`} icon="chip" /></Entrance>
      </Abs>
      <Abs x={110} y={210}>
        <Entrance delay={T(149.7)} dy={40}>
          <GlassCard style={{width: 760, padding: 22}}>
            <LogoTile src="assets/graviton-chip.jpg" w={716} h={420} fit="cover" bg={C.bg} radius={24} zoom={1.1} />
            <div style={{display: 'flex', alignItems: 'center', gap: 20, padding: '22px 14px 6px'}}>
              <div style={{fontSize: 52, fontWeight: 700}}>Graviton চিপ</div>
            </div>
            <div style={{padding: '0 14px 16px', fontSize: 36, fontWeight: 500, color: C.textDim, lineHeight: 1.35}}>AWS-এর নিজস্ব প্রসেসর</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1010} y={190}>
        <Entrance delay={T(151.7)} cfg="bouncy" from={0.85}>
          <Donut pct={49} size={500} delay={T(152.0)} color={C.primary} hero thick={44}>
            <div style={{fontSize: 156, fontWeight: 700, lineHeight: 1.1, ...gradText}}>{bn(49)}%</div>
            <div style={{fontSize: 34, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>পর্যন্ত</div>
          </Donut>
        </Entrance>
      </Abs>
      <Abs x={960} y={740} w={860} style={{textAlign: 'center'}}>
        <Entrance delay={T(153.4)}>
          <div style={{fontSize: 50, fontWeight: 700, lineHeight: 1.35}}>Amazon.com-এর <span style={{color: C.accent}}>EC2 কম্পিউট</span><br />Graviton চিপে চলেছে</div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S17 · ২০২৪: আড়াই লাখ+ চিপ, ৫,৮০০+ সার্ভিস · Bento */
export const S17: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 1100, y: 540, c: 'accent', r: 1000, o: 0.35}}>
      <Sfx t={159.0} n="pop" />
      <Sfx t={161.2} n="pop" />
      <Sfx t={164.2} n="success" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text={`${bn('২০২৪')} সালে`} icon="calendar" /></Entrance>
      </Abs>
      <Abs x={110} y={200}>
        <Entrance delay={T(158.7)} dy={40}>
          <GlassCard style={{width: 760, height: 360, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 30}}>
            <LogoTile src="assets/graviton-logo.jpg" w={700} h={300} fit="cover" bg={C.bg} radius={22} zoom={1.06} />
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={110} y={600}>
        <Entrance delay={T(158.9)} dy={40} cfg="bouncy" from={0.9}>
          <GlassCard hero style={{width: 760, height: 380, padding: '30px 44px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
            <div style={{fontSize: 40, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>চিপ চালিয়েছিল</div>
            <div style={{fontSize: 132, fontWeight: 700, lineHeight: 1.1, ...gradText}}>
              <Counter to={2.5} decimals={1} delay={T(159.2)} format={(v) => bn(v.toFixed(1))} />
              <span style={{fontSize: 62}}> লাখ+</span>
            </div>
            <div style={{fontSize: 38, fontWeight: 600, lineHeight: 1.3}}>আড়াই লাখের বেশি Graviton চিপ</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={920} y={200}>
        <Entrance delay={T(161.1)} dy={40} cfg="bouncy" from={0.9}>
          <GlassCard style={{width: 890, height: 400, padding: '30px 50px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
            <div style={{fontSize: 40, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>আলাদা Amazon.com সার্ভিস</div>
            <div style={{fontSize: 150, fontWeight: 700, lineHeight: 1.1}}>
              <Counter to={5800} delay={T(161.4)} format={(v) => bnInt(v)} />
              <span style={{fontSize: 80, color: C.accent}}>+</span>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={920} y={640}>
        <Entrance delay={T(164.0)} dy={40} cfg="bouncy" from={0.8}>
          <GlassCard style={{width: 890, height: 340, padding: '30px 50px', display: 'flex', alignItems: 'center', gap: 40}}>
            <div style={{fontSize: 190, fontWeight: 700, lineHeight: 1.1, color: C.accent}}>{bn(2)}×</div>
            <div style={{fontSize: 56, fontWeight: 700, lineHeight: 1.35}}>{bn('২০২৩')} এর<br />দ্বিগুণ</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};
