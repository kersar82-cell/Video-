import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {theme, rgba} from '../theme';
import {Abs, Character, Counter, Entrance, Float, GlassCard, KenBurns, LogoTile, SceneFrame, Sfx, Tag, WordReveal, bn, bnInt, gradText, useT} from '../components/primitives';
import {Icon} from '../components/Icon';
import {CheckRow} from '../components/widgets';

const C = theme.colors;
const clamp01 = (n: number) => Math.min(Math.max(n, 0), 1);

/* S18 · যাচাই-সতর্কতা · Checklist */
export const S18: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 900, y: 560, r: 1100}}>
      <Sfx t={166.5} n="click" />
      <Sfx t={169.0} n="click" />
      <Sfx t={173.6} n="success" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="একটা সতর্কতা" icon="alert" /></Entrance>
      </Abs>
      <Abs x={110} y={230} w={1250} style={{display: 'flex', flexDirection: 'column', gap: 52}}>
        <CheckRow delay={T(166.4)} icon="doc" tone="accent" text="এগুলো AWS-এর নিজেদের প্রকাশ করা সংখ্যা" size={46} />
        <CheckRow delay={T(168.6)} icon="question" tone="dim" text="স্বাধীনভাবে যাচাই করা নয়" size={46} />
        <CheckRow delay={T(171.0)} icon="lock" tone="dim" text="Amazon-এর ভেতরের পুরো ডিজাইন বলেনি" size={46} />
        <CheckRow delay={T(173.5)} icon="check" tone="success" text="দুজনের তথ্যেই ক্যাচ আর সিডিএনের বড় ভূমিকা" size={46} />
        <CheckRow delay={T(176.8)} icon="question" tone="dim" text="বাকিটা কীভাবে সাজানো — পুরোটা বলেনি" size={46} />
      </Abs>
      <Character pose="think" h={560} delay={T(175.0)} style={{left: 1480, top: 430}} />
    </SceneFrame>
  );
};

/* S19 · রেজাল্ট সাইট: প্রকাশিত কারণ নেই · Statement + ব্রাউজার */
export const S19: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 1350, y: 520, r: 1100}}>
      <Sfx t={180.1} n="whoosh" />
      <Sfx t={181.0} n="chime" />
      <Sfx t={190.6} n="click" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="এবার রেজাল্ট সাইট" icon="globe" /></Entrance>
      </Abs>
      <Abs x={110} y={190} w={880}>
        <WordReveal text="শুরুতেই *পরিষ্কার করে বলি" size={72} delay={T(180.2)} />
      </Abs>
      <Abs x={110} y={400} w={880}>
        <Entrance delay={T(182.4)} dx={-40} dy={0}>
          <div style={{fontSize: 46, fontWeight: 600, lineHeight: 1.4}}>সাইট ধীর হওয়ার <span style={{color: C.accent}}>প্রযুক্তিগত কারণ</span></div>
        </Entrance>
      </Abs>
      <Abs x={110} y={520} w={880}>
        <Entrance delay={T(185.8)} dx={-40} dy={0}>
          <div style={{fontSize: 46, fontWeight: 600, lineHeight: 1.4}}>শিক্ষা বোর্ড বা কর্তৃপক্ষ প্রকাশ করেছে বলে <span style={{color: C.accent}}>খুঁজে পাইনি</span></div>
        </Entrance>
      </Abs>
      <Abs x={110} y={760} w={880}>
        <Entrance delay={T(190.6)} dx={-40} dy={0} cfg="bouncy">
          <GlassCard hero style={{padding: '26px 36px', display: 'flex', alignItems: 'center', gap: 22}}>
            <Icon n="cross" size={52} color={C.accent} stroke={2.4} />
            <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.3}}>অনুমান করে কারণ বানাবো না</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1060} y={180}>
        <Entrance delay={T(181.2)} dy={50}>
          <GlassCard style={{width: 760, padding: 0}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 12, padding: '16px 22px', background: rgba('text', 0.06)}}>
              {[0, 1, 2].map((i) => <div key={i} style={{width: 16, height: 16, borderRadius: 8, background: rgba('text', 0.25)}} />)}
              <div style={{marginLeft: 16, flex: 1, height: 34, borderRadius: 17, background: rgba('text', 0.08)}} />
            </div>
            <div style={{width: 760, height: 560, overflow: 'hidden', background: C.surface}}>
              <KenBurns src="assets/edu-board-site.jpg" zoomTo={1.1} panX={0} fit="cover" />
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={1300} y={800}>
        <Entrance delay={T(183.2)} cfg="bouncy" from={0.7}>
          <LogoTile src="assets/edu-board-logo.jpg" w={180} radius={90} pad={14} />
        </Entrance>
      </Abs>
      <Character pose="explain" h={520} delay={T(184.0)} style={{left: 1590, top: 560}} />
    </SceneFrame>
  );
};

/* S20 · এইচএসসি ২০২৬ সংখ্যা · Dashboard */
export const S20: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  return (
    <SceneFrame spot={{x: 1000, y: 560, r: 1100}}>
      <Sfx t={196.0} n="pop" />
      <Sfx t={198.0} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="সরকারি পোর্টালের ব্লগ অনুযায়ী" icon="doc" /></Entrance>
      </Abs>
      <Abs x={110} y={170} w={1700}>
        <WordReveal text={`এইচএসসি ${bn('২০২৬')}`} size={84} delay={T(195.0)} />
      </Abs>
      <Abs x={110} y={340}>
        <Entrance delay={T(196.0)} dy={40}>
          <GlassCard style={{width: 760, height: 600, padding: '34px 44px'}}>
            <div style={{fontSize: 40, color: C.textDim, fontWeight: 600, lineHeight: 1.3}}>বোর্ড</div>
            <div style={{fontSize: 190, fontWeight: 700, lineHeight: 1.1, ...gradText}}>
              <Counter to={11} delay={T(196.2)} format={(v) => bn(Math.round(v))} />টি
            </div>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(6, 90px)', gap: 18, marginTop: 24}}>
              {Array.from({length: 11}).map((_, i) => {
                const lit = clamp01((frame - T(196.4) - i * 3) / 6);
                return <div key={i} style={{width: 90, height: 90, borderRadius: 24, background: rgba('primary', 0.15 + 0.65 * lit), border: `2px solid ${rgba('accent', 0.2 + 0.5 * lit)}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Icon n="database" size={44} color={C.text} /></div>;
              })}
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={910} y={340}>
        <Entrance delay={T(198.4)} dy={40} cfg="bouncy" from={0.9}>
          <GlassCard hero style={{width: 900, height: 600, padding: '34px 50px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 18}}>
              <Icon n="users" size={64} color={C.accent} />
              <span style={{fontSize: 44, color: C.textDim, fontWeight: 600}}>মোট পরীক্ষার্থী</span>
            </div>
            <div style={{fontSize: 170, fontWeight: 700, lineHeight: 1.15, ...gradText}}>
              <Counter to={1270583} delay={T(198.8)} format={(v) => bnInt(v)} />
            </div>
            <div style={{fontSize: 40, fontWeight: 600, lineHeight: 1.4}}>জন পরীক্ষার্থী ছিলেন</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S21 · প্রথম ১–২ ঘণ্টা, সার্ভারে চাপ · Process flow + লোড মিটার */
export const S21: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const steps = [
    {t: 203.8, icon: 'doc', label: 'ফল প্রকাশ'},
    {t: 205.6, icon: 'clock', label: 'প্রথম এক দুই ঘণ্টা'},
    {t: 208.0, icon: 'server', label: 'সার্ভারে প্রচণ্ড চাপ'},
    {t: 210.6, icon: 'wifi', label: 'ধীর বা না খোলা'},
  ];
  const load = interpolate(frame, [T(207.8), T(210.0)], [0.15, 0.96], {easing: theme.ease.out, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <SceneFrame spot={{x: 960, y: 640, r: 1200}}>
      <Sfx t={205.6} n="click" />
      <Sfx t={208.0} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="একাধিক রেজাল্ট গাইড অনুযায়ী" icon="search" /></Entrance>
      </Abs>
      <div style={{position: 'absolute', left: 110, right: 110, top: 270, display: 'flex', gap: 30, justifyContent: 'space-between'}}>
        {steps.map((s, i) => (
          <Entrance key={i} delay={T(s.t)} dy={40} cfg="bouncy" from={0.85} style={{width: 395}}>
            <GlassCard hero={i === 2} style={{height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, padding: '0 20px'}}>
              <Icon n={s.icon} size={96} color={i === 2 ? C.text : C.accent} stroke={1.7} />
              <div style={{fontSize: 46, fontWeight: 700, textAlign: 'center', lineHeight: 1.3}}>{s.label}</div>
            </GlassCard>
          </Entrance>
        ))}
      </div>
      <Abs x={110} y={680} w={1700}>
        <Entrance delay={T(207.8)} dy={30}>
          <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
            <span style={{fontSize: 44, fontWeight: 600, color: C.textDim, whiteSpace: 'nowrap'}}>সার্ভারের চাপ</span>
            <div style={{flex: 1, height: 44, borderRadius: 22, background: rgba('text', 0.09), overflow: 'hidden'}}>
              <div style={{width: `${load * 100}%`, height: '100%', borderRadius: 22, background: `linear-gradient(90deg, ${C.accent}, ${C.primary})`, boxShadow: `0 0 40px ${rgba('primary', 0.8)}`}} />
            </div>
          </div>
        </Entrance>
      </Abs>
      <Character pose="disappointed" h={330} delay={T(210.8)} style={{left: 1500, top: 750}} />
    </SceneFrame>
  );
};

/* S22 · একটাই প্রকাশিত কারণ; ভেতরের ঘটনা জানি না · Statement */
export const S22: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  return (
    <SceneFrame spot={{x: 1300, y: 560, r: 1000}}>
      <Sfx t={214.0} n="pop" />
      <Sfx t={218.2} n="click" />
      <Abs x={110} y={100} w={1000}>
        <WordReveal text="প্রকাশিত কারণ *একটাই" size={92} delay={T(213.4)} />
      </Abs>
      <Abs x={110} y={300} w={900}>
        <Entrance delay={T(215.0)} dx={-40} dy={0}>
          <div style={{fontSize: 56, fontWeight: 600, lineHeight: 1.4}}>অনেক মানুষ <span style={{color: C.accent}}>একই সময়ে ঢোকে</span></div>
        </Entrance>
      </Abs>
      <Abs x={110} y={560} w={900}>
        <Entrance delay={T(218.0)} dx={-40} dy={0}>
          <GlassCard style={{padding: '30px 40px', display: 'flex', alignItems: 'center', gap: 26}}>
            <Icon n="question" size={84} color={C.accent} />
            <div style={{fontSize: 48, fontWeight: 700, lineHeight: 1.35}}>সার্ভারের ভেতরে ঠিক কী ঘটে?</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={110} y={800} w={900}>
        <Entrance delay={T(219.4)} cfg="bouncy" from={0.8}>
          <div style={{fontSize: 96, fontWeight: 700, lineHeight: 1.2, ...gradText}}>সেটা আমি জানি না</div>
        </Entrance>
      </Abs>
      <Abs x={1120} y={200}>
        <Entrance delay={T(214.0)} dx={60} dy={0}>
          <GlassCard hero style={{width: 640, height: 700, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 30}}>
            <div style={{display: 'flex', gap: 16}}>
              {[0, 1, 2, 3, 4].map((i) => {
                const u = ((frame - T(214.6)) / 30 + i * 0.2) % 1;
                return <div key={i} style={{opacity: frame > T(214.4) ? 1 : 0, transform: `translateY(${Math.max(u, 0) * 30}px)`}}><Icon n="user" size={64} color={C.accent} /></div>;
              })}
            </div>
            <Icon n="arrowRight" size={70} color={C.textDim} style={{transform: 'rotate(90deg)'}} />
            <Icon n="server" size={220} color={C.text} stroke={1.3} />
          </GlassCard>
        </Entrance>
      </Abs>
      <Character pose="shrug" h={420} delay={T(219.6)} style={{left: 1490, top: 640}} />
    </SceneFrame>
  );
};

/* S23 · তুলনা: Amazon ৪৪,০০০+ পরীক্ষা বনাম বোর্ডের সাইট · Before/After Split */
export const S23: React.FC = () => {
  const T = useT();
  return (
    <SceneFrame spot={{x: 560, y: 560, r: 1000}}>
      <Sfx t={224.2} n="chime" />
      <Sfx t={227.6} n="click" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="তুলনার জন্য একটা তথ্য" icon="search" /></Entrance>
      </Abs>
      <Abs x={110} y={210}>
        <Entrance delay={T(223.6)} dy={40}>
          <GlassCard hero style={{width: 820, height: 760, padding: '40px 48px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20}}>
            <LogoTile src="assets/aws.jpg" w={150} radius={30} />
            <div style={{fontSize: 44, fontWeight: 600, color: C.textDim, textAlign: 'center', lineHeight: 1.35}}>AWS-এর ব্লগ অনুযায়ী Amazon<br />প্রাইম ডের আগে চালিয়েছে</div>
            <div style={{fontSize: 150, fontWeight: 700, lineHeight: 1.15, ...gradText}}>
              <Counter to={44000} delay={T(224.9)} format={(v) => bnInt(v)} />+
            </div>
            <div style={{fontSize: 50, fontWeight: 700, lineHeight: 1.3}}>ব্যর্থতার পরীক্ষা</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={990} y={210}>
        <Entrance delay={T(227.4)} dy={40}>
          <GlassCard style={{width: 820, height: 760, padding: '40px 48px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20}}>
            <LogoTile src="assets/edu-board-logo.jpg" w={150} radius={75} pad={12} />
            <div style={{fontSize: 44, fontWeight: 600, color: C.textDim, textAlign: 'center', lineHeight: 1.35}}>বোর্ডের সাইট কি এমন<br />পরীক্ষা করে?</div>
            <Float amp={8}><div style={{fontSize: 260, fontWeight: 700, lineHeight: 1.1, color: rgba('text', 0.85)}}>?</div></Float>
            <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.3, color: C.accent}}>সেই তথ্য আমি পাইনি</div>
          </GlassCard>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S24 · সাইট না খুললে করণীয় · Option cards */
export const S24: React.FC = () => {
  const T = useT();
  const mono = {fontFamily: theme.fonts.mono, fontWeight: 700 as const};
  return (
    <SceneFrame spot={{x: 900, y: 620, r: 1100}}>
      <Sfx t={236.3} n="pop" />
      <Sfx t={238.4} n="pop" />
      <Sfx t={245.6} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="গাইডগুলো যা বলছে" icon="doc" /></Entrance>
      </Abs>
      <Abs x={110} y={160} w={1500}>
        <WordReveal text="ফল প্রকাশের দিন সাইট *না খুললে" size={72} delay={T(232.4)} per={3} />
      </Abs>
      <Abs x={110} y={310} w={1330}>
        <Entrance delay={T(236.2)} dx={-50} dy={0}>
          <GlassCard style={{padding: '26px 36px', display: 'flex', alignItems: 'center', gap: 28}}>
            <Icon n="clock" size={72} color={C.accent} />
            <div style={{fontSize: 52, fontWeight: 700, lineHeight: 1.3}}>কিছুক্ষণ পর আবার চেষ্টা করুন</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={110} y={500} w={1330}>
        <Entrance delay={T(238.3)} dx={-50} dy={0}>
          <GlassCard hero style={{padding: '26px 36px'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
              <Icon n="link" size={72} color={C.accent} />
              <div style={{fontSize: 52, fontWeight: 700, lineHeight: 1.3}}>সরকারি বিকল্প পোর্টাল ব্যবহার করুন</div>
            </div>
            <div style={{display: 'flex', flexDirection: 'column', gap: 14, marginTop: 22, paddingLeft: 100}}>
              <Entrance delay={T(239.9)} dx={-30} dy={0}><div style={{fontSize: 42, color: C.accent, ...mono}}>educationboardresults.gov.bd</div></Entrance>
              <Entrance delay={T(243.0)} dx={-30} dy={0}><div style={{fontSize: 42, color: C.accent, ...mono}}>edubordresults.gov.bd</div></Entrance>
            </div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Abs x={110} y={830} w={1330}>
        <Entrance delay={T(245.5)} dx={-50} dy={0}>
          <GlassCard style={{padding: '26px 36px', display: 'flex', alignItems: 'center', gap: 28}}>
            <Icon n="sms" size={72} color={C.accent} />
            <div style={{fontSize: 52, fontWeight: 700, lineHeight: 1.3}}>এসএমএসে ফল জানুন</div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Character pose="confident" h={560} delay={T(240.0)} style={{left: 1560, top: 500}} />
    </SceneFrame>
  );
};

/* S25 · স্ক্যাম সতর্কতা · Warning */
export const S25: React.FC = () => {
  const T = useT();
  const asks = [
    {t: 248.5, icon: 'phone', label: 'ফোন নম্বর'},
    {t: 249.6, icon: 'key', label: 'ওটিপি'},
    {t: 250.6, icon: 'card', label: 'পেমেন্ট'},
  ];
  return (
    <SceneFrame spot={{x: 900, y: 560, r: 1100}}>
      <Sfx t={248.5} n="pop" />
      <Sfx t={251.6} n="click" />
      <Abs x={110} y={100}>
        <Entrance delay={2}><Tag text="সাবধান" icon="alert" size={42} /></Entrance>
      </Abs>
      <Abs x={110} y={230} w={1400}>
        <WordReveal text="যে সাইট *চায়" size={86} delay={T(248.0)} />
      </Abs>
      <div style={{position: 'absolute', left: 110, top: 400, display: 'flex', gap: 36}}>
        {asks.map((a, i) => (
          <Entrance key={i} delay={T(a.t)} cfg="bouncy" from={0.8}>
            <GlassCard style={{width: 380, height: 280, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22}}>
              <Icon n={a.icon} size={96} color={C.accent} stroke={1.7} />
              <div style={{fontSize: 52, fontWeight: 700, lineHeight: 1.3}}>{a.label}</div>
            </GlassCard>
          </Entrance>
        ))}
      </div>
      <Abs x={110} y={760} w={1400}>
        <Entrance delay={T(251.5)} cfg="bouncy" from={0.9}>
          <GlassCard hero style={{padding: '30px 44px', display: 'flex', alignItems: 'center', gap: 30}}>
            <Icon n="cross" size={80} color={C.accent} stroke={2.6} />
            <div style={{fontSize: 62, fontWeight: 700, lineHeight: 1.3}}>রোল রেজিস্ট্রেশন <span style={{color: C.accent}}>দেবেন না</span></div>
          </GlassCard>
        </Entrance>
      </Abs>
      <Character pose="worry" h={520} delay={T(251.4)} style={{left: 1610, top: 500}} />
    </SceneFrame>
  );
};

/* S26 · রিক্যাপ · Checklist Recap Grid */
export const S26: React.FC = () => {
  const T = useT();
  const col = (x: number, delay: number, logo: string, title: string, children: React.ReactNode, hero = false, logoBg?: string) => (
    <Abs x={x} y={300}>
      <Entrance delay={T(delay)} dy={40}>
        <GlassCard hero={hero} style={{width: 560, height: 690, padding: '34px 36px'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 22, marginBottom: 26}}>
            <LogoTile src={logo} w={100} radius={24} bg={logoBg} />
            <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.25}}>{title}</div>
          </div>
          <div style={{display: 'flex', flexDirection: 'column', gap: 24}}>{children}</div>
        </GlassCard>
      </Entrance>
    </Abs>
  );
  return (
    <SceneFrame spot={{x: 960, y: 600, r: 1400}}>
      <Sfx t={255.7} n="pop" />
      <Sfx t={260.4} n="pop" />
      <Sfx t={267.7} n="pop" />
      <Abs x={110} y={84}>
        <Entrance delay={2}><Tag text="প্রকাশিত তথ্য অনুযায়ী" icon="doc" /></Entrance>
      </Abs>
      <Abs x={110} y={140} w={1700}>
        <WordReveal text="মূল প্রশ্নের *উত্তর" size={72} delay={T(253.2)} />
      </Abs>
      {col(110, 255.6, 'assets/wikimedia.jpg', 'উইকিপিডিয়া', (
        <CheckRow delay={T(256.2)} text="রিড রিকোয়েস্টের বড় অংশ সিডিএন থেকে" size={42} />
      ))}
      {col(680, 260.2, 'assets/amazon.jpg', 'Amazon', (
        <>
          <CheckRow delay={T(261.2)} text="ক্যাশ" size={44} />
          <CheckRow delay={T(262.4)} text="সিডিএন" size={44} />
          <CheckRow delay={T(263.7)} text="কিউ" size={44} />
          <CheckRow delay={T(264.9)} text="আলাদা ডেটাবেস" size={44} />
          <CheckRow delay={T(266.2)} text="আগাম ব্যর্থতার পরীক্ষা" size={44} />
        </>
      ), false)}
      {col(1250, 267.5, 'assets/edu-board-logo.jpg', 'আমাদের রেজাল্ট সাইট', (
        <>
          <CheckRow delay={T(270.0)} icon="users" tone="accent" text="প্রথম এক দুই ঘণ্টায় লাখ লাখ মানুষ একসাথে ঢোকে" size={42} />
          <CheckRow delay={T(276.3)} icon="question" tone="dim" text="ভেতরের প্রযুক্তিগত কারণ প্রকাশিত নয়" size={42} />
        </>
      ), true)}
    </SceneFrame>
  );
};

/* S27 · এআই বট → অবকাঠামোর চাপ · Flow */
export const S27: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const press = interpolate(frame, [T(286.6), T(288.4)], [0.25, 0.95], {easing: theme.ease.out, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const node = (x: number, delay: number, icon: string, label: string, hero = false) => (
    <Abs x={x} y={560}>
      <Entrance delay={T(delay)} cfg="bouncy" from={0.8}>
        <GlassCard hero={hero} style={{width: 420, height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
          <Icon n={icon} size={110} color={hero ? C.text : C.accent} stroke={1.6} />
          <div style={{fontSize: 44, fontWeight: 700, textAlign: 'center', lineHeight: 1.3}}>{label}</div>
        </GlassCard>
      </Entrance>
    </Abs>
  );
  return (
    <SceneFrame spot={{x: 960, y: 620, r: 1300}}>
      <Sfx t={283.5} n="pop" />
      <Sfx t={286.9} n="click" />
      <Abs x={110} y={110} w={1700} style={{display: 'flex', justifyContent: 'center'}}>
        <WordReveal text="*এআই-এর সাথে এর একটা সম্পর্ক আছে" size={80} align="center" delay={T(280.0)} per={3} />
      </Abs>
      <Abs x={110} y={330} w={1700} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(281.8)}><Tag text="উইকিমিডিয়ার নিজের কথা অনুযায়ী" icon="doc" size={34} /></Entrance>
      </Abs>
      {node(150, 282.4, 'chip', 'এআই মডেলের ডেটা সংগ্রহ')}
      {node(750, 283.4, 'bot', 'বট')}
      {node(1350, 286.4, 'server', 'অবকাঠামো', true)}
      <Abs x={600} y={690}><Entrance delay={T(283.6)} dx={-20} dy={0}><Icon n="arrowRight" size={90} color={C.accent} stroke={2.2} /></Entrance></Abs>
      <Abs x={1200} y={690}><Entrance delay={T(286.6)} dx={-20} dy={0}><Icon n="arrowRight" size={90} color={C.accent} stroke={2.2} /></Entrance></Abs>
      <Abs x={1350} y={930} w={420}>
        <Entrance delay={T(287.0)}>
          <div style={{height: 26, borderRadius: 13, background: rgba('text', 0.1), overflow: 'hidden'}}>
            <div style={{width: `${press * 100}%`, height: '100%', background: `linear-gradient(90deg, ${C.accent}, ${C.primary})`, boxShadow: `0 0 30px ${rgba('primary', 0.7)}`}} />
          </div>
        </Entrance>
      </Abs>
    </SceneFrame>
  );
};

/* S28 · CTA */
export const S28: React.FC = () => {
  const T = useT();
  const frame = useCurrentFrame();
  const click = clamp01((frame - T(290.0, 0)) / 6);
  return (
    <SceneFrame noExit spot={{x: 960, y: 520, r: 1300, o: 0.6}}>
      <Sfx t={288.8} n="whoosh" />
      <Sfx t={290.0} n="success" />
      <Abs x={0} y={250} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <WordReveal text="ভিডিও ভালো লাগলে *সাবস্ক্রাইব করো" size={96} align="center" delay={2} per={4} />
      </Abs>
      <Abs x={0} y={520} w={1920} style={{display: 'flex', justifyContent: 'center'}}>
        <Entrance delay={T(289.3)} cfg="bouncy" from={0.6}>
          <div style={{display: 'flex', alignItems: 'center', gap: 24, padding: '30px 80px', borderRadius: 70, background: C.primary, boxShadow: `0 0 90px ${rgba('primary', 0.75)}`, fontSize: 76, fontWeight: 700, lineHeight: 1.2, transform: `scale(${1 - 0.06 * Math.sin(click * Math.PI)})`}}>
            <Icon n="play" size={70} color={C.text} fill={C.text} stroke={1} />
            সাবস্ক্রাইব
          </div>
        </Entrance>
      </Abs>
      <Character pose="wave" h={440} delay={T(289.2)} style={{left: 1450, top: 600}} />
    </SceneFrame>
  );
};
