// ফ্ল্যাগ: ভয়েসওভার প্রিভিউতে বাজবে; রেন্ডারে ডিফল্টে বন্ধ (props দিয়ে চালু করা যায়)
export const config = {
  voiceoverFile: 'voiceover.mp3',
  tailSeconds: 0.5, // SRT-এর শেষের পর সামান্য হোল্ড
};
