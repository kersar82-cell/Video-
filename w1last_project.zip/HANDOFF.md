# HANDOFF — w1last ভিডিও (Remotion)

## ১. বিষয় ও দৈর্ঘ্য
- বিষয়: Wikimedia (বট ট্রাফিক, কার্টার পেজ ভিউ), AWS প্রাইম ডে ২০২৬ সংখ্যা, এইচএসসি রেজাল্ট সাইট ধীর হওয়ার প্রকাশিত কারণ ও সতর্কতা
- SRT: `public/srt/w1last_ben.srt` (৫১ cue, শেষ 290.82s) → composition ৮৭৪০ ফ্রেম (SRT + ০.৫ সেকেন্ড টেইল), ৩০fps
- ভয়েসওভার নেই (প্রিভিউতে `public/voiceover.mp3` রাখলে বাজবে)

## ২. ইউজারের পছন্দ
- স্টাইল: Dark Tech + Glass Cards
- রং (ইউজারের দেওয়া): bg #080E1B · primary(hero) #1267F5 · accent #16C7F3 · text #F4F7FC · surface #172338 · success #22C58B
- রেশিও: 16:9 (1920×1080), fps 30
- ক্যারেক্টার: `public/char/*.png` (১২ পোজ, rembg দিয়ে কাটা) — ইমোশন অনুযায়ী ৮টি সিনে

## ৩. সিনের তালিকা (সব ২৮টি কোড লেখা ও স্টিল যাচাই শেষ)
S01 হুক +৫০% · S02 বট→Commons · S03 ৬৫%/৩৫% · S04 মানুষ বনাম ক্রলার · S05 কার্টার ২৮ লাখ+ · S06 ডিবেট→২× (shock) · S07 সংযোগ ভরে → ঠিক · S08 ক্রলার আটকানো · S09 AWS + ২৩–২৬ জুন · S10 DynamoDB bento · S11 ১৯.২ কোটি/সেকেন্ড গজ · S12 ElastiCache · S13 CloudFront · S14 SQS · S15 ফল্ট ইনজেকশন (৭৩৩ → ৪৪,০০০+) · S16 Graviton ৪৯% · S17 ২০২৪ চিপ/সার্ভিস · S18 সতর্কতা (think) · S19 রেজাল্ট সাইট (explain) · S20 এইচএসসি সংখ্যা · S21 প্রথম ১–২ ঘণ্টা (disappointed) · S22 একটাই কারণ (shrug) · S23 ৪৪,০০০+ তুলনা · S24 করণীয় (confident) · S25 স্ক্যাম সাবধান (worry) · S26 রিক্যাপ · S27 এআই বট চাপ · S28 CTA (wave)
- সিনের শুরু-শেষ: `src/timeline.tsx` (সেকেন্ডে, SRT cue সীমা থেকে)

## ৪. অনুমান ও সন্দেহ
- cue-র ভেতরের বাক্য ভাগ (যেমন S08/S09, S17/S18, S21/S22, S23/S24) অক্ষরের অনুপাতে আনুমানিক; SRT-তে শব্দ-সময় নেই
- ব্যবহার হয়নি: `unknown-elastic` (Elastic লোগো, ElastiCache নয়), `unknown-cloudflare`, `unknown-blue-yellow` (পরিচয় অনিশ্চিত), ২টি Pinterest MP4 (বিষয়ের সাথে মিল নেই)
- URL SRT-এর বানানেই: `edubordresults.gov.bd` — বানান মিলিয়ে নিন
- ফন্ট: Hind Siliguri (বাংলা+ল্যাটিন), JetBrains Mono (URL) — `public/fonts/`
- SFX: ইউজারের ৮টি ফাইল ছেঁটে `public/sfx/`-এ (whoosh, swipe, pop, click, tick, chime, success)

## ৫. রেন্ডার
- Chromium সমস্যায়: `--browser-executable=/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell`
- `npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17`
- ভয়েসওভারসহ: শেষে `--props='{"includeVoiceover":true}'`
- প্রিভিউ স্টিল: `./shots.sh` (frames.txt)

## ৬. পরবর্তী ধাপ
- প্রিভিউ অনুমোদন/সংশোধন → "রেন্ডার করো" বললে MP4 (SFX সহ)
- নতুন চ্যাটে ZIP আপলোড করে "চালিয়ে যাও" বা "শুধু রেন্ডার করো"
