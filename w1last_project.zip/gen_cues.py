import re, json
txt = open('public/srt/w1last_ben.srt', encoding='utf-8').read().strip()
blocks = re.split(r'\n\s*\n', txt)
cues = []
def sec(t):
    h, m, rest = t.split(':'); s, ms = rest.split(',')
    return int(h)*3600 + int(m)*60 + int(s) + int(ms)/1000
for b in blocks:
    lines = b.strip().split('\n')
    i = int(lines[0]); a, z = lines[1].split(' --> ')
    cues.append({'i': i, 'start': sec(a), 'end': sec(z), 'text': ' '.join(lines[2:])})
open('src/cues.ts', 'w', encoding='utf-8').write(
  '// Auto-generated from public/srt/w1last_ben.srt (gen_cues.py) — SRT is the only timing source\n'
  'export type Cue = {i: number; start: number; end: number; text: string};\n'
  'export const cues: Cue[] = ' + json.dumps(cues, ensure_ascii=False, indent=1) + ';\n')
for c in cues: print(c['i'], round(c['start'],2), round(c['end'],2), c['text'][:40])
print(len(cues), cues[-1]['end'])
