#!/bin/bash
B=/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell
i=1
for f in $(cat frames.txt); do
  npx remotion still src/index.ts Main out/s$(printf %02d $i).png --frame $f --browser-executable=$B --overwrite >/dev/null 2>&1
  i=$((i+1))
done
